/**
 * Database Module for Discord Economy Bot
 * Handles SQLite database operations
 */

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

class Database {
    constructor() {
        this.dbPath = process.env.DATABASE_PATH || path.join(__dirname, 'bot.db');
        this.db = null;
        
        // Ensure database directory exists
        const dbDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }
    }

    /**
     * Initialize database connection and create tables
     */
    async initialize() {
        return new Promise((resolve, reject) => {
            this.db = new sqlite3.Database(this.dbPath, (err) => {
                if (err) {
                    reject(err);
                    return;
                }
                
                console.log('Connected to SQLite database');
                this.createTables()
                    .then(() => resolve())
                    .catch(reject);
            });
        });
    }

    /**
     * Create all necessary tables
     */
    async createTables() {
        const tables = [
            // Users table for economy system
            `CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                balance INTEGER DEFAULT 1000,
                bank_balance INTEGER DEFAULT 0,
                daily_streak INTEGER DEFAULT 0,
                last_daily TEXT,
                last_work TEXT,
                total_earned INTEGER DEFAULT 0,
                total_spent INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                experience INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Items table for shop system
            `CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                price INTEGER NOT NULL,
                category TEXT DEFAULT 'misc',
                emoji TEXT,
                sellable BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Inventory table for user items
            `CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                item_id INTEGER NOT NULL,
                quantity INTEGER DEFAULT 1,
                acquired_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items (id),
                UNIQUE(user_id, item_id)
            )`,

            // Transactions table for economy logging
            `CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                description TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Warnings table for moderation
            `CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                moderator_id TEXT NOT NULL,
                reason TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Guild settings table
            `CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id TEXT PRIMARY KEY,
                prefix TEXT DEFAULT '!',
                welcome_channel TEXT,
                log_channel TEXT,
                mute_role TEXT,
                settings TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Role reactions table
            `CREATE TABLE IF NOT EXISTS role_reactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                message_id TEXT NOT NULL,
                emoji TEXT NOT NULL,
                role_id TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(message_id, emoji)
            )`,

            // Auto reactions table
            `CREATE TABLE IF NOT EXISTS auto_reactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                trigger_type TEXT NOT NULL,
                trigger_value TEXT NOT NULL,
                emoji TEXT NOT NULL,
                enabled BOOLEAN DEFAULT 1,
                uses INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Giveaways table
            `CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                message_id TEXT,
                title TEXT NOT NULL,
                description TEXT,
                prize TEXT NOT NULL,
                winner_count INTEGER DEFAULT 1,
                end_time TEXT NOT NULL,
                host_id TEXT NOT NULL,
                ended BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Giveaway entries table
            `CREATE TABLE IF NOT EXISTS giveaway_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER NOT NULL,
                user_id TEXT NOT NULL,
                entered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id),
                UNIQUE(giveaway_id, user_id)
            )`,

            // Giveaway winners table
            `CREATE TABLE IF NOT EXISTS giveaway_winners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER NOT NULL,
                user_id TEXT NOT NULL,
                ticket_channel_id TEXT,
                claim_deadline TEXT,
                claimed BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id)
            )`
        ];

        for (const table of tables) {
            await this.run(table);
        }

        // Insert default shop items
        await this.insertDefaultItems();
    }

    /**
     * Insert default shop items
     */
    async insertDefaultItems() {
        const defaultItems = [
            { name: 'Coffee', description: 'A hot cup of coffee to boost your energy', price: 50, category: 'food', emoji: '☕' },
            { name: 'Pizza', description: 'Delicious pizza slice', price: 100, category: 'food', emoji: '🍕' },
            { name: 'Laptop', description: 'A powerful laptop for work', price: 2000, category: 'electronics', emoji: '💻' },
            { name: 'Phone', description: 'Latest smartphone', price: 1500, category: 'electronics', emoji: '📱' },
            { name: 'Car', description: 'A nice car to drive around', price: 50000, category: 'vehicles', emoji: '🚗' },
            { name: 'House', description: 'A beautiful house to live in', price: 500000, category: 'property', emoji: '🏠' },
            { name: 'Diamond', description: 'A precious diamond', price: 10000, category: 'jewelry', emoji: '💎' },
            { name: 'Gold Bar', description: 'Pure gold bar', price: 5000, category: 'precious', emoji: '🥇' },
            { name: 'Fishing Rod', description: 'For catching fish', price: 200, category: 'tools', emoji: '🎣' },
            { name: 'Lottery Ticket', description: 'Try your luck!', price: 100, category: 'gambling', emoji: '🎫' }
        ];

        for (const item of defaultItems) {
            try {
                await this.run(
                    'INSERT OR IGNORE INTO items (name, description, price, category, emoji) VALUES (?, ?, ?, ?, ?)',
                    [item.name, item.description, item.price, item.category, item.emoji]
                );
            } catch (error) {
                // Item already exists, ignore
            }
        }
    }

    /**
     * Execute a SQL query that returns data
     */
    async get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    /**
     * Execute a SQL query that returns multiple rows
     */
    async all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }

    /**
     * Execute a SQL query that modifies data
     */
    async run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, changes: this.changes });
            });
        });
    }

    /**
     * Get or create user in database
     */
    async getUser(userId) {
        let user = await this.get('SELECT * FROM users WHERE user_id = ?', [userId]);
        
        if (!user) {
            await this.run(
                'INSERT INTO users (user_id) VALUES (?)',
                [userId]
            );
            user = await this.get('SELECT * FROM users WHERE user_id = ?', [userId]);
        }
        
        return user;
    }

    /**
     * Update user balance
     */
    async updateBalance(userId, amount, type = 'wallet') {
        const column = type === 'bank' ? 'bank_balance' : 'balance';
        await this.run(
            `UPDATE users SET ${column} = ${column} + ? WHERE user_id = ?`,
            [amount, userId]
        );
        
        // Log transaction
        await this.run(
            'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
            [userId, type, amount, `Balance ${amount > 0 ? 'increase' : 'decrease'}`]
        );
    }

    /**
     * Get user inventory
     */
    async getUserInventory(userId) {
        return await this.all(`
            SELECT i.*, inv.quantity 
            FROM inventory inv 
            JOIN items i ON inv.item_id = i.id 
            WHERE inv.user_id = ?
        `, [userId]);
    }

    /**
     * Add item to user inventory
     */
    async addToInventory(userId, itemId, quantity = 1) {
        const existing = await this.get(
            'SELECT * FROM inventory WHERE user_id = ? AND item_id = ?',
            [userId, itemId]
        );

        if (existing) {
            await this.run(
                'UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?',
                [quantity, userId, itemId]
            );
        } else {
            await this.run(
                'INSERT INTO inventory (user_id, item_id, quantity) VALUES (?, ?, ?)',
                [userId, itemId, quantity]
            );
        }
    }

    /**
     * Remove item from user inventory
     */
    async removeFromInventory(userId, itemId, quantity = 1) {
        const existing = await this.get(
            'SELECT * FROM inventory WHERE user_id = ? AND item_id = ?',
            [userId, itemId]
        );

        if (!existing || existing.quantity < quantity) {
            return false;
        }

        if (existing.quantity === quantity) {
            await this.run(
                'DELETE FROM inventory WHERE user_id = ? AND item_id = ?',
                [userId, itemId]
            );
        } else {
            await this.run(
                'UPDATE inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?',
                [quantity, userId, itemId]
            );
        }

        return true;
    }

    /**
     * Get shop items
     */
    async getShopItems(category = null) {
        if (category) {
            return await this.all('SELECT * FROM items WHERE category = ? ORDER BY price', [category]);
        }
        return await this.all('SELECT * FROM items ORDER BY category, price');
    }

    /**
     * Get item by name
     */
    async getItemByName(name) {
        return await this.get('SELECT * FROM items WHERE LOWER(name) = LOWER(?)', [name]);
    }

    /**
     * Close database connection
     */
    close() {
        if (this.db) {
            this.db.close();
        }
    }
}

module.exports = Database;

