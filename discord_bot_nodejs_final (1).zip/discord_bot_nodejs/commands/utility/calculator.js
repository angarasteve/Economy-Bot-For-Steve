/**
 * Calculator Command
 * Perform mathematical calculations
 */

const { createEmbed, createErrorEmbed, cleanCodeBlock } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'calculator',
        description: 'Perform mathematical calculations',
        aliases: ['calc', 'math'],
        usage: '!calculator <expression>',
        category: 'utility',
        cooldown: 3
    },

    async execute(message, args, client) {
        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please provide a mathematical expression.\\n**Usage:** \`${client.config.prefix}calculator <expression>\`\\n**Example:** \`${client.config.prefix}calculator 2 + 2 * 3\``
            );
            return await message.reply({ embeds: [embed] });
        }

        let expression = args.join(' ');
        expression = cleanCodeBlock(expression);

        // Security: Only allow safe mathematical operations
        const safeExpression = expression.replace(/[^0-9+\-*/.() ]/g, '');
        
        if (safeExpression !== expression) {
            const embed = createErrorEmbed(
                '❌ Invalid Expression',
                'Please use only numbers and basic mathematical operators (+, -, *, /, parentheses).'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (!safeExpression.trim()) {
            const embed = createErrorEmbed(
                '❌ Empty Expression',
                'Please provide a valid mathematical expression.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Evaluate the expression safely
            const result = Function(`"use strict"; return (${safeExpression})`)();

            // Check if result is a valid number
            if (typeof result !== 'number' || !isFinite(result)) {
                throw new Error('Invalid result');
            }

            // Format the result
            let formattedResult = result.toString();
            if (result % 1 !== 0 && result.toString().includes('.')) {
                // Round to 10 decimal places for floating point numbers
                formattedResult = result.toFixed(10).replace(/\\.?0+$/, '');
            }

            // Create result embed
            const embed = createEmbed(
                '🧮 Calculator Result',
                '',
                0x00FF00
            );

            embed.addFields(
                {
                    name: '📝 Expression',
                    value: `\`\`\`${expression}\`\`\``,
                    inline: false
                },
                {
                    name: '✅ Result',
                    value: `\`\`\`${formattedResult}\`\`\``,
                    inline: false
                }
            );

            // Add some additional info for interesting results
            if (Math.abs(result) > 1000000) {
                embed.addFields({
                    name: '📊 Scientific Notation',
                    value: `\`${result.toExponential(3)}\``,
                    inline: true
                });
            }

            if (result % 1 === 0 && result > 1) {
                // Check if it's a perfect square
                const sqrt = Math.sqrt(result);
                if (sqrt % 1 === 0) {
                    embed.addFields({
                        name: '🔢 Perfect Square',
                        value: `√${result} = ${sqrt}`,
                        inline: true
                    });
                }
            }

            embed.setFooter({ 
                text: 'Supports +, -, *, /, parentheses, and decimal numbers' 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Calculator error:', error);
            
            const embed = createErrorEmbed(
                '❌ Calculation Error',
                'Invalid mathematical expression. Please check your syntax and try again.\\n\\n**Examples:**\\n• `2 + 2`\\n• `(5 * 3) - 2`\\n• `10 / 2.5`\\n• `2 * (3 + 4)`'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

