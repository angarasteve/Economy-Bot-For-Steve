/**
 * Help Command
 * Display available commands and their usage
 */

const { createEmbed, capitalize, paginate } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'help',
        description: 'Display available commands and their usage',
        aliases: ['commands', 'h'],
        usage: '!help [command/category]',
        category: 'utility',
        cooldown: 3
    },

    async execute(message, args, client) {
        const prefix = client.config.prefix;

        // If a specific command is requested
        if (args.length > 0) {
            const commandName = args[0].toLowerCase();
            const command = client.commands.get(commandName) || 
                          client.commands.find(cmd => cmd.data.aliases && cmd.data.aliases.includes(commandName));

            if (command) {
                // Show detailed command info
                const embed = createEmbed(
                    `📖 Command: ${command.data.name}`,
                    command.data.description,
                    0x0099FF
                );

                embed.addFields(
                    {
                        name: '📝 Usage',
                        value: `\`${command.data.usage || `${prefix}${command.data.name}`}\``,
                        inline: true
                    },
                    {
                        name: '📂 Category',
                        value: capitalize(command.data.category || 'general'),
                        inline: true
                    },
                    {
                        name: '⏰ Cooldown',
                        value: `${command.data.cooldown || 3} seconds`,
                        inline: true
                    }
                );

                if (command.data.aliases && command.data.aliases.length > 0) {
                    embed.addFields({
                        name: '🔗 Aliases',
                        value: command.data.aliases.map(alias => `\`${alias}\``).join(', '),
                        inline: false
                    });
                }

                embed.setFooter({ 
                    text: `Use ${prefix}help to see all commands` 
                });

                return await message.reply({ embeds: [embed] });
            } else {
                // Check if it's a category
                const categories = {};
                client.commands.forEach(cmd => {
                    const category = cmd.data.category || 'general';
                    if (!categories[category]) categories[category] = [];
                    categories[category].push(cmd);
                });

                if (categories[commandName]) {
                    // Show category commands
                    const categoryCommands = categories[commandName];
                    const embed = createEmbed(
                        `📂 ${capitalize(commandName)} Commands`,
                        `All commands in the ${commandName} category:`,
                        0x0099FF
                    );

                    const commandList = categoryCommands
                        .map(cmd => `\`${cmd.data.name}\` - ${cmd.data.description}`)
                        .join('\\n');

                    embed.addFields({
                        name: `Commands [${categoryCommands.length}]`,
                        value: commandList,
                        inline: false
                    });

                    embed.setFooter({ 
                        text: `Use ${prefix}help <command> for detailed info about a command` 
                    });

                    return await message.reply({ embeds: [embed] });
                }

                // Command/category not found
                const embed = createEmbed(
                    '❌ Not Found',
                    `Command or category "${commandName}" not found.\\nUse \`${prefix}help\` to see all available commands.`,
                    0xFF0000
                );
                return await message.reply({ embeds: [embed] });
            }
        }

        // Show general help with all commands organized by category
        try {
            const categories = {};
            client.commands.forEach(cmd => {
                const category = cmd.data.category || 'general';
                if (!categories[category]) categories[category] = [];
                categories[category].push(cmd);
            });

            const embed = createEmbed(
                '📚 Bot Commands',
                `Here are all available commands. Use \`${prefix}help <command>\` for detailed information.`,
                0x0099FF
            );

            // Add each category as a field
            Object.keys(categories).sort().forEach(categoryName => {
                const commands = categories[categoryName];
                const commandList = commands
                    .map(cmd => `\`${cmd.data.name}\``)
                    .join(', ');

                embed.addFields({
                    name: `${getCategoryEmoji(categoryName)} ${capitalize(categoryName)} [${commands.length}]`,
                    value: commandList,
                    inline: false
                });
            });

            // Add bot info
            embed.addFields(
                {
                    name: '🤖 Bot Info',
                    value: `**Prefix:** \`${prefix}\`\\n**Commands:** ${client.commands.size}\\n**Version:** ${client.config.version}`,
                    inline: true
                },
                {
                    name: '🔗 Useful Links',
                    value: '[Support Server](https://discord.gg/example) • [Invite Bot](https://discord.com/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=8&scope=bot)',
                    inline: true
                }
            );

            embed.setFooter({ 
                text: `Use ${prefix}help <category> to see commands in a specific category` 
            });

            embed.setThumbnail(client.user.displayAvatarURL({ dynamic: true }));

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in help command:', error);
            await message.reply('❌ An error occurred while loading the help menu.');
        }
    }
};

/**
 * Get emoji for category
 */
function getCategoryEmoji(category) {
    const emojis = {
        economy: '💰',
        moderation: '🛡️',
        fun: '🎮',
        utility: '🔧',
        music: '🎵',
        roles: '🎭',
        autoreact: '🤖',
        giveaway: '🎁',
        general: '📋'
    };
    return emojis[category] || '📋';
}

