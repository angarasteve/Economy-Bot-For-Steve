/**
 * Server Info Command
 * Display detailed information about the server
 */

const { createEmbed, getTimeAgo, formatNumber } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'serverinfo',
        description: 'Get detailed information about the server',
        aliases: ['server', 'guild', 'si'],
        usage: '!serverinfo',
        category: 'utility',
        cooldown: 5
    },

    async execute(message, args, client) {
        const guild = message.guild;

        try {
            // Fetch additional guild data
            await guild.members.fetch();
            
            // Create server info embed
            const embed = createEmbed(
                `🏰 Server Information - ${guild.name}`,
                '',
                0x0099FF
            );

            // Basic server information
            embed.addFields(
                {
                    name: '🏷️ Basic Info',
                    value: `**Name:** ${guild.name}\\n**ID:** ${guild.id}\\n**Owner:** <@${guild.ownerId}>\\n**Created:** <t:${Math.floor(guild.createdTimestamp / 1000)}:F>`,
                    inline: true
                },
                {
                    name: '📊 Statistics',
                    value: `**Members:** ${formatNumber(guild.memberCount)}\\n**Channels:** ${formatNumber(guild.channels.cache.size)}\\n**Roles:** ${formatNumber(guild.roles.cache.size)}\\n**Emojis:** ${formatNumber(guild.emojis.cache.size)}`,
                    inline: true
                }
            );

            // Member breakdown
            const members = guild.members.cache;
            const humans = members.filter(member => !member.user.bot).size;
            const bots = members.filter(member => member.user.bot).size;
            const online = members.filter(member => member.presence?.status === 'online').size;
            const idle = members.filter(member => member.presence?.status === 'idle').size;
            const dnd = members.filter(member => member.presence?.status === 'dnd').size;
            const offline = members.filter(member => !member.presence || member.presence.status === 'offline').size;

            embed.addFields(
                {
                    name: '👥 Members',
                    value: `**Humans:** ${formatNumber(humans)}\\n**Bots:** ${formatNumber(bots)}\\n**Total:** ${formatNumber(guild.memberCount)}`,
                    inline: true
                },
                {
                    name: '📊 Status',
                    value: `🟢 Online: ${formatNumber(online)}\\n🟡 Idle: ${formatNumber(idle)}\\n🔴 DND: ${formatNumber(dnd)}\\n⚫ Offline: ${formatNumber(offline)}`,
                    inline: true
                }
            );

            // Channel breakdown
            const channels = guild.channels.cache;
            const textChannels = channels.filter(channel => channel.type === 0).size; // GUILD_TEXT
            const voiceChannels = channels.filter(channel => channel.type === 2).size; // GUILD_VOICE
            const categories = channels.filter(channel => channel.type === 4).size; // GUILD_CATEGORY
            const threads = channels.filter(channel => [10, 11, 12].includes(channel.type)).size; // Thread types

            embed.addFields({
                name: '📺 Channels',
                value: `**Text:** ${formatNumber(textChannels)}\\n**Voice:** ${formatNumber(voiceChannels)}\\n**Categories:** ${formatNumber(categories)}\\n**Threads:** ${formatNumber(threads)}`,
                inline: true
            });

            // Server features
            const features = guild.features;
            const featureList = [];
            
            if (features.includes('VERIFIED')) featureList.push('✅ Verified');
            if (features.includes('PARTNERED')) featureList.push('🤝 Partnered');
            if (features.includes('COMMUNITY')) featureList.push('🌐 Community');
            if (features.includes('NEWS')) featureList.push('📰 News');
            if (features.includes('DISCOVERABLE')) featureList.push('🔍 Discoverable');
            if (features.includes('MONETIZATION_ENABLED')) featureList.push('💰 Monetization');
            if (features.includes('MORE_EMOJI')) featureList.push('😀 More Emoji');
            if (features.includes('BANNER')) featureList.push('🖼️ Banner');
            if (features.includes('VANITY_URL')) featureList.push('🔗 Vanity URL');

            if (featureList.length > 0) {
                embed.addFields({
                    name: '✨ Features',
                    value: featureList.join('\\n'),
                    inline: true
                });
            }

            // Boost information
            if (guild.premiumSubscriptionCount > 0) {
                embed.addFields({
                    name: '💎 Nitro Boosts',
                    value: `**Level:** ${guild.premiumTier}\\n**Boosts:** ${guild.premiumSubscriptionCount}\\n**Boosters:** ${guild.members.cache.filter(member => member.premiumSince).size}`,
                    inline: true
                });
            }

            // Verification and content filter
            const verificationLevels = {
                0: 'None',
                1: 'Low',
                2: 'Medium',
                3: 'High',
                4: 'Very High'
            };

            const contentFilterLevels = {
                0: 'Disabled',
                1: 'Members without roles',
                2: 'All members'
            };

            embed.addFields({
                name: '🔒 Security',
                value: `**Verification:** ${verificationLevels[guild.verificationLevel]}\\n**Content Filter:** ${contentFilterLevels[guild.explicitContentFilter]}\\n**MFA Required:** ${guild.mfaLevel ? 'Yes' : 'No'}`,
                inline: true
            });

            // Server icon and banner
            if (guild.iconURL()) {
                embed.setThumbnail(guild.iconURL({ dynamic: true, size: 256 }));
            }

            if (guild.bannerURL()) {
                embed.setImage(guild.bannerURL({ dynamic: true, size: 1024 }));
            }

            // Footer
            embed.setFooter({ 
                text: `Server created ${getTimeAgo(guild.createdAt)}`,
                iconURL: guild.iconURL({ dynamic: true })
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in serverinfo command:', error);
            await message.reply('❌ An error occurred while fetching server information.');
        }
    }
};

