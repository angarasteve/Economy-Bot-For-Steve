/**
 * User Info Command
 * Display detailed information about a user
 */

const { createEmbed, getTimeAgo, formatNumber } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'userinfo',
        description: 'Get detailed information about a user',
        aliases: ['user', 'whois', 'ui'],
        usage: '!userinfo [@user]',
        category: 'utility',
        cooldown: 3
    },

    async execute(message, args, client) {
        // Get target user (mentioned user or command author)
        const target = message.mentions.members.first() || message.member;
        const user = target.user;

        try {
            // Create user info embed
            const embed = createEmbed(
                `👤 User Information - ${user.username}`,
                '',
                target.displayHexColor || 0x0099FF
            );

            // Basic user information
            embed.addFields(
                {
                    name: '🏷️ Basic Info',
                    value: `**Username:** ${user.username}#${user.discriminator}\\n**Display Name:** ${target.displayName}\\n**ID:** ${user.id}\\n**Bot:** ${user.bot ? 'Yes' : 'No'}`,
                    inline: true
                },
                {
                    name: '📅 Account Created',
                    value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>\\n(${getTimeAgo(user.createdAt)})`,
                    inline: true
                },
                {
                    name: '📥 Joined Server',
                    value: target.joinedAt 
                        ? `<t:${Math.floor(target.joinedTimestamp / 1000)}:F>\\n(${getTimeAgo(target.joinedAt)})`
                        : 'Unknown',
                    inline: true
                }
            );

            // Server-specific information
            if (target.premiumSince) {
                embed.addFields({
                    name: '💎 Nitro Booster',
                    value: `Since <t:${Math.floor(target.premiumSinceTimestamp / 1000)}:F>\\n(${getTimeAgo(target.premiumSince)})`,
                    inline: true
                });
            }

            // Roles information
            const roles = target.roles.cache
                .filter(role => role.id !== message.guild.id) // Exclude @everyone
                .sort((a, b) => b.position - a.position)
                .map(role => role.toString())
                .slice(0, 10); // Limit to 10 roles

            if (roles.length > 0) {
                embed.addFields({
                    name: `🎭 Roles [${target.roles.cache.size - 1}]`,
                    value: roles.join(', ') + (target.roles.cache.size > 11 ? '...' : ''),
                    inline: false
                });
            }

            // Permissions (if user has notable permissions)
            const notablePerms = [];
            if (target.permissions.has('Administrator')) notablePerms.push('Administrator');
            if (target.permissions.has('ManageGuild')) notablePerms.push('Manage Server');
            if (target.permissions.has('ManageChannels')) notablePerms.push('Manage Channels');
            if (target.permissions.has('ManageMessages')) notablePerms.push('Manage Messages');
            if (target.permissions.has('KickMembers')) notablePerms.push('Kick Members');
            if (target.permissions.has('BanMembers')) notablePerms.push('Ban Members');
            if (target.permissions.has('ModerateMembers')) notablePerms.push('Moderate Members');

            if (notablePerms.length > 0) {
                embed.addFields({
                    name: '🔑 Key Permissions',
                    value: notablePerms.join(', '),
                    inline: false
                });
            }

            // Status and activity
            const presence = target.presence;
            if (presence) {
                let statusText = 'Unknown';
                switch (presence.status) {
                    case 'online': statusText = '🟢 Online'; break;
                    case 'idle': statusText = '🟡 Idle'; break;
                    case 'dnd': statusText = '🔴 Do Not Disturb'; break;
                    case 'offline': statusText = '⚫ Offline'; break;
                }

                embed.addFields({
                    name: '📊 Status',
                    value: statusText,
                    inline: true
                });

                // Activities
                if (presence.activities && presence.activities.length > 0) {
                    const activity = presence.activities[0];
                    let activityText = activity.name;
                    
                    if (activity.type === 'PLAYING') activityText = `🎮 Playing ${activity.name}`;
                    else if (activity.type === 'STREAMING') activityText = `📺 Streaming ${activity.name}`;
                    else if (activity.type === 'LISTENING') activityText = `🎵 Listening to ${activity.name}`;
                    else if (activity.type === 'WATCHING') activityText = `👀 Watching ${activity.name}`;

                    embed.addFields({
                        name: '🎯 Activity',
                        value: activityText,
                        inline: true
                    });
                }
            }

            // User avatar
            embed.setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }));

            // Footer with additional info
            embed.setFooter({ 
                text: `Requested by ${message.author.username}`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in userinfo command:', error);
            await message.reply('❌ An error occurred while fetching user information.');
        }
    }
};

