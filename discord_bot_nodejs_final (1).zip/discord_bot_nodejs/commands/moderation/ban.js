/**
 * Ban Command
 * Ban a member from the server
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'ban',
        description: 'Ban a member from the server',
        aliases: ['banish'],
        usage: '!ban <@user> [days] [reason]',
        category: 'moderation',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'BanMembers')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Ban Members** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'BanMembers')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Ban Members** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please mention a user to ban.\\n**Usage:** \`${client.config.prefix}ban <@user> [days] [reason]\`\\n**Example:** \`${client.config.prefix}ban @user 7 Repeated violations\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const target = message.mentions.members.first();
        let deleteMessageDays = 0;
        let reason = 'No reason provided';

        // Parse arguments (days and reason)
        if (args.length > 1) {
            const secondArg = parseInt(args[1]);
            if (!isNaN(secondArg) && secondArg >= 0 && secondArg <= 7) {
                deleteMessageDays = secondArg;
                reason = args.slice(2).join(' ') || 'No reason provided';
            } else {
                reason = args.slice(1).join(' ');
            }
        }

        if (!target) {
            const embed = createErrorEmbed(
                '❌ Invalid User',
                'Please mention a valid member to ban.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to ban themselves
        if (target.id === message.author.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'You cannot ban yourself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to ban the bot
        if (target.id === client.user.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'I cannot ban myself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check role hierarchy
        if (target.roles.highest.position >= message.member.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'You cannot ban someone with a role equal to or higher than yours.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot can ban the target
        if (target.roles.highest.position >= message.guild.members.me.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'I cannot ban someone with a role equal to or higher than mine.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if target is bannable
        if (!target.bannable) {
            const embed = createErrorEmbed(
                '❌ Cannot Ban',
                'I cannot ban this user. They may have higher permissions or be the server owner.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Try to send DM to user before banning
            try {
                const dmEmbed = createEmbed(
                    '🔨 You have been banned',
                    `You were banned from **${message.guild.name}**.`,
                    0xFF0000
                );
                dmEmbed.addFields(
                    {
                        name: '👮 Moderator',
                        value: message.author.username,
                        inline: true
                    },
                    {
                        name: '📝 Reason',
                        value: reason,
                        inline: true
                    }
                );
                if (deleteMessageDays > 0) {
                    dmEmbed.addFields({
                        name: '🗑️ Message Deletion',
                        value: `Messages from the last ${deleteMessageDays} day${deleteMessageDays > 1 ? 's' : ''} will be deleted.`,
                        inline: false
                    });
                }
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled, continue with ban
            }

            // Ban the user
            await target.ban({ 
                deleteMessageDays: deleteMessageDays,
                reason: `${reason} | Banned by ${message.author.username}`
            });

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Member Banned',
                `**${target.user.username}** has been banned from the server.`
            );

            embed.addFields(
                {
                    name: '👤 User',
                    value: `${target.user.username}#${target.user.discriminator}\\n(${target.id})`,
                    inline: true
                },
                {
                    name: '👮 Moderator',
                    value: `${message.author.username}#${message.author.discriminator}`,
                    inline: true
                },
                {
                    name: '📝 Reason',
                    value: reason,
                    inline: false
                }
            );

            if (deleteMessageDays > 0) {
                embed.addFields({
                    name: '🗑️ Message Deletion',
                    value: `Messages from the last ${deleteMessageDays} day${deleteMessageDays > 1 ? 's' : ''} were deleted.`,
                    inline: false
                });
            }

            embed.setThumbnail(target.user.displayAvatarURL({ dynamic: true }));
            embed.setFooter({ 
                text: `User ID: ${target.id}` 
            });

            await message.reply({ embeds: [embed] });

            // Log to database if needed
            try {
                await client.db.run(
                    'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                    [target.id, 'moderation', 0, `Banned by ${message.author.username}: ${reason}`]
                );
            } catch (error) {
                // Database logging failed, but ban was successful
            }

        } catch (error) {
            console.error('Error in ban command:', error);
            const embed = createErrorEmbed(
                '❌ Ban Failed',
                'An error occurred while trying to ban the user. Please check my permissions and try again.'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

