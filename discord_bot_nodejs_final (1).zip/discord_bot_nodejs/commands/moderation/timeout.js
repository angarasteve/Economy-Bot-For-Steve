/**
 * Timeout Command
 * Timeout a member (Discord's built-in timeout feature)
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission, parseTime, formatDuration } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'timeout',
        description: 'Timeout a member',
        aliases: ['mute', 'silence'],
        usage: '!timeout <@user> <duration> [reason]',
        category: 'moderation',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'ModerateMembers')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Moderate Members** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'ModerateMembers')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Moderate Members** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 2) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please mention a user and specify duration.\\n**Usage:** \`${client.config.prefix}timeout <@user> <duration> [reason]\`\\n**Example:** \`${client.config.prefix}timeout @user 10m Spamming\`\\n**Duration formats:** 1m, 1h, 1d`
            );
            return await message.reply({ embeds: [embed] });
        }

        const target = message.mentions.members.first();
        const duration = parseTime(args[1]);
        const reason = args.slice(2).join(' ') || 'No reason provided';

        if (!target) {
            const embed = createErrorEmbed(
                '❌ Invalid User',
                'Please mention a valid member to timeout.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (!duration || duration < 1000 || duration > 2419200000) { // 1 second to 28 days
            const embed = createErrorEmbed(
                '❌ Invalid Duration',
                'Please provide a valid duration between 1 second and 28 days.\\n**Examples:** 10m, 1h, 2d'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to timeout themselves
        if (target.id === message.author.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'You cannot timeout yourself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to timeout the bot
        if (target.id === client.user.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'I cannot timeout myself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check role hierarchy
        if (target.roles.highest.position >= message.member.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'You cannot timeout someone with a role equal to or higher than yours.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot can timeout the target
        if (target.roles.highest.position >= message.guild.members.me.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'I cannot timeout someone with a role equal to or higher than mine.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if target is moderatable
        if (!target.moderatable) {
            const embed = createErrorEmbed(
                '❌ Cannot Timeout',
                'I cannot timeout this user. They may have higher permissions or be the server owner.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Try to send DM to user before timeout
            try {
                const dmEmbed = createEmbed(
                    '🔇 You have been timed out',
                    `You were timed out in **${message.guild.name}**.`,
                    0xFFAA00
                );
                dmEmbed.addFields(
                    {
                        name: '👮 Moderator',
                        value: message.author.username,
                        inline: true
                    },
                    {
                        name: '⏰ Duration',
                        value: formatDuration(duration),
                        inline: true
                    },
                    {
                        name: '📝 Reason',
                        value: reason,
                        inline: false
                    }
                );
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled, continue with timeout
            }

            // Timeout the user
            await target.timeout(duration, reason);

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Member Timed Out',
                `**${target.user.username}** has been timed out.`
            );

            embed.addFields(
                {
                    name: '👤 User',
                    value: `${target.user.username}#${target.user.discriminator}\\n(${target.id})`,
                    inline: true
                },
                {
                    name: '👮 Moderator',
                    value: `${message.author.username}#${message.author.discriminator}`,
                    inline: true
                },
                {
                    name: '⏰ Duration',
                    value: formatDuration(duration),
                    inline: true
                },
                {
                    name: '📝 Reason',
                    value: reason,
                    inline: false
                },
                {
                    name: '🕐 Expires',
                    value: `<t:${Math.floor((Date.now() + duration) / 1000)}:R>`,
                    inline: false
                }
            );

            embed.setThumbnail(target.user.displayAvatarURL({ dynamic: true }));
            embed.setFooter({ 
                text: `User ID: ${target.id}` 
            });

            await message.reply({ embeds: [embed] });

            // Log to database if needed
            try {
                await client.db.run(
                    'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                    [target.id, 'moderation', 0, `Timed out by ${message.author.username} for ${formatDuration(duration)}: ${reason}`]
                );
            } catch (error) {
                // Database logging failed, but timeout was successful
            }

        } catch (error) {
            console.error('Error in timeout command:', error);
            const embed = createErrorEmbed(
                '❌ Timeout Failed',
                'An error occurred while trying to timeout the user. Please check my permissions and try again.'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

