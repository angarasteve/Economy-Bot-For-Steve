/**
 * Kick Command
 * Kick a member from the server
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'kick',
        description: 'Kick a member from the server',
        aliases: ['remove'],
        usage: '!kick <@user> [reason]',
        category: 'moderation',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'KickMembers')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Kick Members** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'KickMembers')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Kick Members** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please mention a user to kick.\\n**Usage:** \`${client.config.prefix}kick <@user> [reason]\`\\n**Example:** \`${client.config.prefix}kick @user Spamming\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const target = message.mentions.members.first();
        const reason = args.slice(1).join(' ') || 'No reason provided';

        if (!target) {
            const embed = createErrorEmbed(
                '❌ Invalid User',
                'Please mention a valid member to kick.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to kick themselves
        if (target.id === message.author.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'You cannot kick yourself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to kick the bot
        if (target.id === client.user.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'I cannot kick myself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check role hierarchy
        if (target.roles.highest.position >= message.member.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'You cannot kick someone with a role equal to or higher than yours.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot can kick the target
        if (target.roles.highest.position >= message.guild.members.me.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'I cannot kick someone with a role equal to or higher than mine.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if target is kickable
        if (!target.kickable) {
            const embed = createErrorEmbed(
                '❌ Cannot Kick',
                'I cannot kick this user. They may have higher permissions or be the server owner.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Try to send DM to user before kicking
            try {
                const dmEmbed = createEmbed(
                    '👢 You have been kicked',
                    `You were kicked from **${message.guild.name}**.`,
                    0xFF0000
                );
                dmEmbed.addFields(
                    {
                        name: '👮 Moderator',
                        value: message.author.username,
                        inline: true
                    },
                    {
                        name: '📝 Reason',
                        value: reason,
                        inline: true
                    }
                );
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled, continue with kick
            }

            // Kick the user
            await target.kick(reason);

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Member Kicked',
                `**${target.user.username}** has been kicked from the server.`
            );

            embed.addFields(
                {
                    name: '👤 User',
                    value: `${target.user.username}#${target.user.discriminator}\\n(${target.id})`,
                    inline: true
                },
                {
                    name: '👮 Moderator',
                    value: `${message.author.username}#${message.author.discriminator}`,
                    inline: true
                },
                {
                    name: '📝 Reason',
                    value: reason,
                    inline: false
                }
            );

            embed.setThumbnail(target.user.displayAvatarURL({ dynamic: true }));
            embed.setFooter({ 
                text: `User ID: ${target.id}` 
            });

            await message.reply({ embeds: [embed] });

            // Log to database if needed
            try {
                await client.db.run(
                    'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                    [target.id, 'moderation', 0, `Kicked by ${message.author.username}: ${reason}`]
                );
            } catch (error) {
                // Database logging failed, but kick was successful
            }

        } catch (error) {
            console.error('Error in kick command:', error);
            const embed = createErrorEmbed(
                '❌ Kick Failed',
                'An error occurred while trying to kick the user. Please check my permissions and try again.'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

