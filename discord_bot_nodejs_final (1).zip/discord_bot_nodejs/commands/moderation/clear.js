/**
 * Clear Command
 * Delete multiple messages from a channel
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'clear',
        description: 'Delete multiple messages from the channel',
        aliases: ['purge', 'delete'],
        usage: '!clear <amount> [@user]',
        category: 'moderation',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'ManageMessages')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Manage Messages** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'ManageMessages')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Manage Messages** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify the number of messages to delete.\\n**Usage:** \`${client.config.prefix}clear <amount> [@user]\`\\n**Example:** \`${client.config.prefix}clear 10\` or \`${client.config.prefix}clear 5 @user\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const amount = parseInt(args[0]);
        const target = message.mentions.users.first();

        // Validate amount
        if (isNaN(amount) || amount < 1 || amount > 100) {
            const embed = createErrorEmbed(
                '❌ Invalid Amount',
                'Please enter a valid number between 1 and 100.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Fetch messages
            const messages = await message.channel.messages.fetch({ 
                limit: amount + 1 // +1 to account for the command message
            });

            let messagesToDelete = Array.from(messages.values());

            // Filter by user if specified
            if (target) {
                messagesToDelete = messagesToDelete.filter(msg => msg.author.id === target.id);
            }

            // Remove the command message from deletion list
            messagesToDelete = messagesToDelete.filter(msg => msg.id !== message.id);

            // Filter out messages older than 14 days (Discord limitation)
            const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
            const recentMessages = messagesToDelete.filter(msg => msg.createdTimestamp > twoWeeksAgo);
            const oldMessages = messagesToDelete.length - recentMessages.length;

            if (recentMessages.length === 0) {
                const embed = createErrorEmbed(
                    '❌ No Messages to Delete',
                    target 
                        ? `No recent messages found from ${target.username}.`
                        : 'No recent messages found to delete.'
                );
                return await message.reply({ embeds: [embed] });
            }

            // Delete messages
            let deletedCount = 0;
            if (recentMessages.length === 1) {
                // Delete single message
                await recentMessages[0].delete();
                deletedCount = 1;
            } else {
                // Bulk delete multiple messages
                const deleted = await message.channel.bulkDelete(recentMessages, true);
                deletedCount = deleted.size;
            }

            // Delete the command message
            try {
                await message.delete();
            } catch (error) {
                // Command message might already be deleted or we don't have permission
            }

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Messages Cleared',
                `Successfully deleted **${deletedCount}** message${deletedCount !== 1 ? 's' : ''}.`
            );

            embed.addFields(
                {
                    name: '📊 Details',
                    value: target 
                        ? `**Target:** ${target.username}\\n**Deleted:** ${deletedCount} messages`
                        : `**Deleted:** ${deletedCount} messages`,
                    inline: true
                },
                {
                    name: '👮 Moderator',
                    value: message.author.username,
                    inline: true
                }
            );

            if (oldMessages > 0) {
                embed.addFields({
                    name: '⚠️ Note',
                    value: `${oldMessages} message${oldMessages !== 1 ? 's' : ''} older than 14 days could not be deleted due to Discord limitations.`,
                    inline: false
                });
            }

            embed.setFooter({ 
                text: 'This message will be automatically deleted in 10 seconds.' 
            });

            // Send confirmation and auto-delete after 10 seconds
            const confirmMessage = await message.channel.send({ embeds: [embed] });
            setTimeout(async () => {
                try {
                    await confirmMessage.delete();
                } catch (error) {
                    // Message might already be deleted
                }
            }, 10000);

            // Log to database if needed
            try {
                await client.db.run(
                    'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                    [message.author.id, 'moderation', deletedCount, `Cleared ${deletedCount} messages${target ? ` from ${target.username}` : ''}`]
                );
            } catch (error) {
                // Database logging failed, but clear was successful
            }

        } catch (error) {
            console.error('Error in clear command:', error);
            const embed = createErrorEmbed(
                '❌ Clear Failed',
                'An error occurred while trying to delete messages. Please check my permissions and try again.'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

