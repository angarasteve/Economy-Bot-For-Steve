/**
 * Reaction Role Command
 * Setup reaction roles for automatic role assignment
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'reactionrole',
        description: 'Setup reaction roles for automatic role assignment',
        aliases: ['rr', 'reactrole'],
        usage: '!reactionrole <add/remove/list> [message_id] [emoji] [role]',
        category: 'roles',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'ManageRoles')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Manage Roles** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'ManageRoles')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Manage Roles** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify an action.\\n**Usage:**\\n• \`${client.config.prefix}reactionrole add <message_id> <emoji> <role>\`\\n• \`${client.config.prefix}reactionrole remove <message_id> <emoji>\`\\n• \`${client.config.prefix}reactionrole list\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const action = args[0].toLowerCase();

        try {
            if (action === 'list') {
                // List all reaction roles in this guild
                const reactionRoles = await client.db.all(
                    'SELECT * FROM role_reactions WHERE guild_id = ?',
                    [message.guild.id]
                );

                if (reactionRoles.length === 0) {
                    const embed = createEmbed(
                        '📋 Reaction Roles',
                        'No reaction roles are currently set up in this server.',
                        0x0099FF
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const embed = createEmbed(
                    '📋 Reaction Roles',
                    `Found ${reactionRoles.length} reaction role${reactionRoles.length > 1 ? 's' : ''} in this server:`,
                    0x0099FF
                );

                for (const rr of reactionRoles.slice(0, 10)) { // Limit to 10 for embed space
                    const role = message.guild.roles.cache.get(rr.role_id);
                    const roleName = role ? role.name : 'Unknown Role';
                    
                    embed.addFields({
                        name: `${rr.emoji} → ${roleName}`,
                        value: `Message ID: \`${rr.message_id}\``,
                        inline: true
                    });
                }

                if (reactionRoles.length > 10) {
                    embed.setFooter({ text: `Showing first 10 of ${reactionRoles.length} reaction roles` });
                }

                return await message.reply({ embeds: [embed] });

            } else if (action === 'add') {
                if (args.length < 4) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Usage',
                        `Please provide message ID, emoji, and role.\\n**Usage:** \`${client.config.prefix}reactionrole add <message_id> <emoji> <role>\`\\n**Example:** \`${client.config.prefix}reactionrole add 123456789 🎮 Gamer\``
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const messageId = args[1];
                const emoji = args[2];
                const roleName = args.slice(3).join(' ');

                // Find the message
                let targetMessage;
                try {
                    targetMessage = await message.channel.messages.fetch(messageId);
                } catch (error) {
                    const embed = createErrorEmbed(
                        '❌ Message Not Found',
                        'Could not find a message with that ID in this channel.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Find the role
                const role = message.guild.roles.cache.find(r => 
                    r.name.toLowerCase() === roleName.toLowerCase() ||
                    r.id === roleName ||
                    r.toString() === roleName
                );

                if (!role) {
                    const embed = createErrorEmbed(
                        '❌ Role Not Found',
                        `Role "${roleName}" was not found in this server.`
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Check role hierarchy
                if (role.position >= message.guild.members.me.roles.highest.position) {
                    const embed = createErrorEmbed(
                        '❌ Role Hierarchy',
                        'I cannot manage a role equal to or higher than my highest role.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Check if reaction role already exists
                const existing = await client.db.get(
                    'SELECT * FROM role_reactions WHERE message_id = ? AND emoji = ?',
                    [messageId, emoji]
                );

                if (existing) {
                    const embed = createErrorEmbed(
                        '❌ Reaction Role Exists',
                        'A reaction role with this emoji already exists on this message.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Add reaction to message
                try {
                    await targetMessage.react(emoji);
                } catch (error) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Emoji',
                        'Could not add that emoji to the message. Please use a valid emoji.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Save to database
                await client.db.run(
                    'INSERT INTO role_reactions (guild_id, message_id, emoji, role_id) VALUES (?, ?, ?, ?)',
                    [message.guild.id, messageId, emoji, role.id]
                );

                const embed = createSuccessEmbed(
                    '✅ Reaction Role Added',
                    `Successfully set up reaction role: ${emoji} → **${role.name}**`
                );

                embed.addFields(
                    {
                        name: '📝 Message',
                        value: `[Jump to Message](${targetMessage.url})`,
                        inline: true
                    },
                    {
                        name: '🎭 Role',
                        value: role.toString(),
                        inline: true
                    },
                    {
                        name: '😀 Emoji',
                        value: emoji,
                        inline: true
                    }
                );

                await message.reply({ embeds: [embed] });

            } else if (action === 'remove') {
                if (args.length < 3) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Usage',
                        `Please provide message ID and emoji.\\n**Usage:** \`${client.config.prefix}reactionrole remove <message_id> <emoji>\`\\n**Example:** \`${client.config.prefix}reactionrole remove 123456789 🎮\``
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const messageId = args[1];
                const emoji = args[2];

                // Check if reaction role exists
                const existing = await client.db.get(
                    'SELECT * FROM role_reactions WHERE message_id = ? AND emoji = ?',
                    [messageId, emoji]
                );

                if (!existing) {
                    const embed = createErrorEmbed(
                        '❌ Reaction Role Not Found',
                        'No reaction role found with that message ID and emoji.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Remove from database
                await client.db.run(
                    'DELETE FROM role_reactions WHERE message_id = ? AND emoji = ?',
                    [messageId, emoji]
                );

                // Try to remove reaction from message
                try {
                    const targetMessage = await message.channel.messages.fetch(messageId);
                    const reaction = targetMessage.reactions.cache.find(r => r.emoji.name === emoji || r.emoji.toString() === emoji);
                    if (reaction) {
                        await reaction.users.remove(client.user);
                    }
                } catch (error) {
                    // Message might not exist anymore, but we still removed from database
                }

                const embed = createSuccessEmbed(
                    '✅ Reaction Role Removed',
                    `Successfully removed reaction role: ${emoji}`
                );

                await message.reply({ embeds: [embed] });

            } else {
                const embed = createErrorEmbed(
                    '❌ Invalid Action',
                    'Please specify `add`, `remove`, or `list`.'
                );
                await message.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Error in reactionrole command:', error);
            await message.reply('❌ An error occurred while managing reaction roles.');
        }
    }
};

