/**
 * Role Command
 * Manage user roles (add/remove)
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'role',
        description: 'Add or remove roles from users',
        aliases: ['addrole', 'removerole'],
        usage: '!role <add/remove> <@user> <role name>',
        category: 'roles',
        cooldown: 3
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'ManageRoles')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Manage Roles** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot has permission
        if (!hasPermission(message.guild.members.me, 'ManageRoles')) {
            const embed = createErrorEmbed(
                '❌ Bot Missing Permissions',
                'I need the **Manage Roles** permission to execute this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 3) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify action, user, and role.\\n**Usage:** \`${client.config.prefix}role <add/remove> <@user> <role name>\`\\n**Example:** \`${client.config.prefix}role add @user Member\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const action = args[0].toLowerCase();
        const target = message.mentions.members.first();
        const roleName = args.slice(2).join(' ');

        // Validate action
        if (!['add', 'remove'].includes(action)) {
            const embed = createErrorEmbed(
                '❌ Invalid Action',
                'Please specify either `add` or `remove`.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (!target) {
            const embed = createErrorEmbed(
                '❌ Invalid User',
                'Please mention a valid member.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Find role
        const role = message.guild.roles.cache.find(r => 
            r.name.toLowerCase() === roleName.toLowerCase() ||
            r.id === roleName ||
            r.toString() === roleName
        );

        if (!role) {
            const embed = createErrorEmbed(
                '❌ Role Not Found',
                `Role "${roleName}" was not found in this server.`
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check role hierarchy
        if (role.position >= message.member.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'You cannot manage a role equal to or higher than your highest role.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if bot can manage the role
        if (role.position >= message.guild.members.me.roles.highest.position) {
            const embed = createErrorEmbed(
                '❌ Role Hierarchy',
                'I cannot manage a role equal to or higher than my highest role.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if role is manageable
        if (!role.editable) {
            const embed = createErrorEmbed(
                '❌ Cannot Manage Role',
                'This role cannot be managed by the bot.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            if (action === 'add') {
                // Check if user already has the role
                if (target.roles.cache.has(role.id)) {
                    const embed = createErrorEmbed(
                        '❌ Role Already Assigned',
                        `${target.user.username} already has the **${role.name}** role.`
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Add role
                await target.roles.add(role);

                const embed = createSuccessEmbed(
                    '✅ Role Added',
                    `Successfully added the **${role.name}** role to ${target.user.username}.`
                );

                embed.addFields(
                    {
                        name: '👤 User',
                        value: `${target.user.username}#${target.user.discriminator}`,
                        inline: true
                    },
                    {
                        name: '🎭 Role',
                        value: role.toString(),
                        inline: true
                    },
                    {
                        name: '👮 Moderator',
                        value: message.author.username,
                        inline: true
                    }
                );

                await message.reply({ embeds: [embed] });

            } else if (action === 'remove') {
                // Check if user has the role
                if (!target.roles.cache.has(role.id)) {
                    const embed = createErrorEmbed(
                        '❌ Role Not Assigned',
                        `${target.user.username} doesn't have the **${role.name}** role.`
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Remove role
                await target.roles.remove(role);

                const embed = createSuccessEmbed(
                    '✅ Role Removed',
                    `Successfully removed the **${role.name}** role from ${target.user.username}.`
                );

                embed.addFields(
                    {
                        name: '👤 User',
                        value: `${target.user.username}#${target.user.discriminator}`,
                        inline: true
                    },
                    {
                        name: '🎭 Role',
                        value: role.toString(),
                        inline: true
                    },
                    {
                        name: '👮 Moderator',
                        value: message.author.username,
                        inline: true
                    }
                );

                await message.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Error in role command:', error);
            const embed = createErrorEmbed(
                '❌ Role Management Failed',
                'An error occurred while managing the role. Please check my permissions and try again.'
            );
            await message.reply({ embeds: [embed] });
        }
    }
};

