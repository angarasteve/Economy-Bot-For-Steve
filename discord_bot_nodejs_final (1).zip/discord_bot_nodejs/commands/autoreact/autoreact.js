/**
 * Auto React Command
 * Manage automatic reactions to messages based on triggers
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, hasPermission } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'autoreact',
        description: 'Manage automatic reactions to messages',
        aliases: ['ar', 'autoresponse'],
        usage: '!autoreact <add/remove/list> [trigger] [emoji]',
        category: 'autoreact',
        cooldown: 5
    },

    async execute(message, args, client) {
        // Check if user has permission
        if (!hasPermission(message.member, 'ManageMessages')) {
            const embed = createErrorEmbed(
                '❌ Insufficient Permissions',
                'You need the **Manage Messages** permission to use this command.'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify an action.\\n**Usage:**\\n• \`${client.config.prefix}autoreact add <trigger> <emoji>\`\\n• \`${client.config.prefix}autoreact remove <id>\`\\n• \`${client.config.prefix}autoreact list\`\\n\\n**Trigger Types:**\\n• \`keyword:hello\` - React when message contains "hello"\\n• \`exact:good morning\` - React to exact phrase\\n• \`starts:!\` - React when message starts with "!"\\n• \`ends:?\` - React when message ends with "?"\\n• \`user:123456789\` - React to specific user's messages\\n• \`channel:123456789\` - React in specific channel`
            );
            return await message.reply({ embeds: [embed] });
        }

        const action = args[0].toLowerCase();

        try {
            if (action === 'list') {
                // List all auto reactions in this guild
                const autoReacts = await client.db.all(
                    'SELECT * FROM auto_reactions WHERE guild_id = ? ORDER BY id',
                    [message.guild.id]
                );

                if (autoReacts.length === 0) {
                    const embed = createEmbed(
                        '🤖 Auto Reactions',
                        'No auto reactions are currently set up in this server.',
                        0x0099FF
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const embed = createEmbed(
                    '🤖 Auto Reactions',
                    `Found ${autoReacts.length} auto reaction${autoReacts.length > 1 ? 's' : ''} in this server:`,
                    0x0099FF
                );

                for (const ar of autoReacts.slice(0, 10)) { // Limit to 10 for embed space
                    const status = ar.enabled ? '✅' : '❌';
                    embed.addFields({
                        name: `${status} ID: ${ar.id} | ${ar.emoji}`,
                        value: `**Type:** ${ar.trigger_type}\\n**Trigger:** ${ar.trigger_value}\\n**Uses:** ${ar.uses}`,
                        inline: true
                    });
                }

                if (autoReacts.length > 10) {
                    embed.setFooter({ text: `Showing first 10 of ${autoReacts.length} auto reactions` });
                }

                return await message.reply({ embeds: [embed] });

            } else if (action === 'add') {
                if (args.length < 3) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Usage',
                        `Please provide trigger and emoji.\\n**Usage:** \`${client.config.prefix}autoreact add <trigger> <emoji>\`\\n**Example:** \`${client.config.prefix}autoreact add keyword:hello 👋\``
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const triggerInput = args[1];
                const emoji = args[2];

                // Parse trigger
                const triggerParts = triggerInput.split(':');
                if (triggerParts.length !== 2) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Trigger Format',
                        'Trigger must be in format `type:value`.\\n**Examples:** `keyword:hello`, `exact:good morning`, `user:123456789`'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const triggerType = triggerParts[0].toLowerCase();
                const triggerValue = triggerParts[1];

                const validTypes = ['keyword', 'exact', 'starts', 'ends', 'user', 'channel'];
                if (!validTypes.includes(triggerType)) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Trigger Type',
                        `Valid trigger types: ${validTypes.map(t => `\`${t}\``).join(', ')}`
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Validate emoji by trying to react with it
                try {
                    await message.react(emoji);
                    await message.reactions.cache.get(emoji)?.users.remove(client.user);
                } catch (error) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Emoji',
                        'Could not use that emoji. Please use a valid emoji.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Check if similar auto reaction already exists
                const existing = await client.db.get(
                    'SELECT * FROM auto_reactions WHERE guild_id = ? AND trigger_type = ? AND trigger_value = ? AND emoji = ?',
                    [message.guild.id, triggerType, triggerValue, emoji]
                );

                if (existing) {
                    const embed = createErrorEmbed(
                        '❌ Auto Reaction Exists',
                        'An auto reaction with this trigger and emoji already exists.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Add to database
                const result = await client.db.run(
                    'INSERT INTO auto_reactions (guild_id, trigger_type, trigger_value, emoji) VALUES (?, ?, ?, ?)',
                    [message.guild.id, triggerType, triggerValue, emoji]
                );

                const embed = createSuccessEmbed(
                    '✅ Auto Reaction Added',
                    `Successfully added auto reaction: ${emoji}`
                );

                embed.addFields(
                    {
                        name: '🎯 Trigger',
                        value: `**Type:** ${triggerType}\\n**Value:** ${triggerValue}`,
                        inline: true
                    },
                    {
                        name: '😀 Emoji',
                        value: emoji,
                        inline: true
                    },
                    {
                        name: '🆔 ID',
                        value: result.id.toString(),
                        inline: true
                    }
                );

                await message.reply({ embeds: [embed] });

            } else if (action === 'remove') {
                if (args.length < 2) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Usage',
                        `Please provide the auto reaction ID.\\n**Usage:** \`${client.config.prefix}autoreact remove <id>\`\\n**Example:** \`${client.config.prefix}autoreact remove 5\``
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const id = parseInt(args[1]);
                if (isNaN(id)) {
                    const embed = createErrorEmbed(
                        '❌ Invalid ID',
                        'Please provide a valid auto reaction ID number.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Check if auto reaction exists
                const existing = await client.db.get(
                    'SELECT * FROM auto_reactions WHERE id = ? AND guild_id = ?',
                    [id, message.guild.id]
                );

                if (!existing) {
                    const embed = createErrorEmbed(
                        '❌ Auto Reaction Not Found',
                        'No auto reaction found with that ID in this server.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Remove from database
                await client.db.run(
                    'DELETE FROM auto_reactions WHERE id = ? AND guild_id = ?',
                    [id, message.guild.id]
                );

                const embed = createSuccessEmbed(
                    '✅ Auto Reaction Removed',
                    `Successfully removed auto reaction: ${existing.emoji}`
                );

                embed.addFields({
                    name: '🎯 Removed Trigger',
                    value: `**Type:** ${existing.trigger_type}\\n**Value:** ${existing.trigger_value}\\n**Uses:** ${existing.uses}`,
                    inline: false
                });

                await message.reply({ embeds: [embed] });

            } else if (action === 'toggle') {
                if (args.length < 2) {
                    const embed = createErrorEmbed(
                        '❌ Invalid Usage',
                        `Please provide the auto reaction ID.\\n**Usage:** \`${client.config.prefix}autoreact toggle <id>\``
                    );
                    return await message.reply({ embeds: [embed] });
                }

                const id = parseInt(args[1]);
                if (isNaN(id)) {
                    const embed = createErrorEmbed(
                        '❌ Invalid ID',
                        'Please provide a valid auto reaction ID number.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Check if auto reaction exists
                const existing = await client.db.get(
                    'SELECT * FROM auto_reactions WHERE id = ? AND guild_id = ?',
                    [id, message.guild.id]
                );

                if (!existing) {
                    const embed = createErrorEmbed(
                        '❌ Auto Reaction Not Found',
                        'No auto reaction found with that ID in this server.'
                    );
                    return await message.reply({ embeds: [embed] });
                }

                // Toggle enabled status
                const newStatus = !existing.enabled;
                await client.db.run(
                    'UPDATE auto_reactions SET enabled = ? WHERE id = ?',
                    [newStatus, id]
                );

                const embed = createSuccessEmbed(
                    `✅ Auto Reaction ${newStatus ? 'Enabled' : 'Disabled'}`,
                    `Auto reaction ${existing.emoji} is now ${newStatus ? 'enabled' : 'disabled'}.`
                );

                await message.reply({ embeds: [embed] });

            } else {
                const embed = createErrorEmbed(
                    '❌ Invalid Action',
                    'Please specify `add`, `remove`, `toggle`, or `list`.'
                );
                await message.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Error in autoreact command:', error);
            await message.reply('❌ An error occurred while managing auto reactions.');
        }
    }
};

