/**
 * Pay Command
 * Transfer money to another user
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, formatCurrency } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'pay',
        description: 'Send money to another user',
        aliases: ['give', 'transfer'],
        usage: '!pay <@user> <amount>',
        category: 'economy',
        cooldown: 5
    },

    async execute(message, args, client) {
        if (args.length < 2) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please mention a user and specify an amount.\\n**Usage:** \`${client.config.prefix}pay <@user> <amount>\`\\n**Example:** \`${client.config.prefix}pay @user 100\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const sender = message.author;
        const recipient = message.mentions.users.first();
        const amount = parseInt(args[1]);

        // Validate recipient
        if (!recipient) {
            const embed = createErrorEmbed(
                '❌ Invalid User',
                'Please mention a valid user to send money to.'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to pay themselves
        if (recipient.id === sender.id) {
            const embed = createErrorEmbed(
                '❌ Invalid Transaction',
                'You cannot send money to yourself!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Check if trying to pay a bot
        if (recipient.bot) {
            const embed = createErrorEmbed(
                '❌ Invalid Recipient',
                'You cannot send money to bots!'
            );
            return await message.reply({ embeds: [embed] });
        }

        // Validate amount
        if (isNaN(amount) || amount < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Amount',
                'Please enter a valid amount (minimum 1 coin).'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (amount > 1000000) {
            const embed = createErrorEmbed(
                '❌ Amount Too Large',
                'Maximum transfer amount is 1,000,000 coins per transaction.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Get sender data
            const senderData = await client.db.getUser(sender.id);

            // Check if sender has enough money
            if (senderData.balance < amount) {
                const embed = createErrorEmbed(
                    '💸 Insufficient Funds',
                    `You need ${formatCurrency(amount)} to complete this transfer.\\nYou currently have ${formatCurrency(senderData.balance)}.\\nYou need ${formatCurrency(amount - senderData.balance)} more.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Get or create recipient data
            const recipientData = await client.db.getUser(recipient.id);

            // Process transfer
            await client.db.updateBalance(sender.id, -amount);
            await client.db.updateBalance(recipient.id, amount);

            // Log transactions
            await client.db.run(
                'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                [sender.id, 'transfer_out', -amount, `Sent to ${recipient.username}`]
            );
            await client.db.run(
                'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)',
                [recipient.id, 'transfer_in', amount, `Received from ${sender.username}`]
            );

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Transfer Successful!',
                `${sender.username} sent ${formatCurrency(amount)} to ${recipient.username}.`
            );

            embed.addFields(
                {
                    name: '👤 Sender',
                    value: `${sender.username}\\n**New Balance:** ${formatCurrency(senderData.balance - amount)}`,
                    inline: true
                },
                {
                    name: '👤 Recipient',
                    value: `${recipient.username}\\n**New Balance:** ${formatCurrency(recipientData.balance + amount)}`,
                    inline: true
                },
                {
                    name: '💰 Amount',
                    value: formatCurrency(amount),
                    inline: true
                }
            );

            embed.setFooter({ 
                text: 'Money transfers are final and cannot be undone!' 
            });

            await message.reply({ embeds: [embed] });

            // Try to notify recipient via DM
            try {
                const dmEmbed = createEmbed(
                    '💰 Money Received!',
                    `You received ${formatCurrency(amount)} from **${sender.username}** in **${message.guild.name}**.`,
                    0x00FF00
                );
                await recipient.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled, ignore
            }

        } catch (error) {
            console.error('Error in pay command:', error);
            await message.reply('❌ An error occurred while processing the transfer.');
        }
    }
};

