/**
 * Daily Command
 * Claim daily rewards with streak bonuses
 */

const { createEmbed, createErrorEmbed, formatCurrency, getRandomNumber } = require('../../utils/helpers');
const moment = require('moment');

module.exports = {
    data: {
        name: 'daily',
        description: 'Claim your daily reward',
        aliases: ['dailyreward'],
        usage: '!daily',
        category: 'economy',
        cooldown: 5
    },

    async execute(message, args, client) {
        const userId = message.author.id;

        try {
            // Get user data
            const userData = await client.db.getUser(userId);
            const now = moment();
            const lastDaily = userData.last_daily ? moment(userData.last_daily) : null;

            // Check if user can claim daily reward (24 hours cooldown)
            if (lastDaily && now.diff(lastDaily, 'hours') < 24) {
                const timeLeft = 24 - now.diff(lastDaily, 'hours');
                const embed = createErrorEmbed(
                    '⏰ Daily Reward Already Claimed',
                    `You can claim your next daily reward in **${timeLeft} hours**.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Calculate streak
            let newStreak = 1;
            if (lastDaily) {
                const hoursDiff = now.diff(lastDaily, 'hours');
                if (hoursDiff >= 24 && hoursDiff <= 48) {
                    // Maintain streak if claimed within 24-48 hours
                    newStreak = userData.daily_streak + 1;
                } else if (hoursDiff > 48) {
                    // Reset streak if more than 48 hours
                    newStreak = 1;
                }
            }

            // Calculate reward amount
            const baseReward = getRandomNumber(100, 500);
            const streakBonus = Math.min(newStreak * 10, 200); // Max 200 bonus
            const totalReward = baseReward + streakBonus;

            // Update user data
            await client.db.updateBalance(userId, totalReward);
            await client.db.run(
                'UPDATE users SET last_daily = ?, daily_streak = ? WHERE user_id = ?',
                [now.toISOString(), newStreak, userId]
            );

            // Create success embed
            const embed = createEmbed(
                '🎁 Daily Reward Claimed!',
                '',
                0x00FF00
            );

            embed.addFields(
                {
                    name: '💰 Base Reward',
                    value: formatCurrency(baseReward),
                    inline: true
                },
                {
                    name: '🔥 Streak Bonus',
                    value: formatCurrency(streakBonus),
                    inline: true
                },
                {
                    name: '💎 Total Earned',
                    value: formatCurrency(totalReward),
                    inline: true
                },
                {
                    name: '📈 Current Streak',
                    value: `${newStreak} day${newStreak > 1 ? 's' : ''}`,
                    inline: true
                },
                {
                    name: '⏰ Next Claim',
                    value: `<t:${Math.floor(now.add(24, 'hours').unix())}:R>`,
                    inline: true
                }
            );

            // Add streak milestone messages
            if (newStreak === 7) {
                embed.addFields({
                    name: '🏆 Milestone Reached!',
                    value: "You've maintained a 7-day streak! Keep it up!",
                    inline: false
                });
            } else if (newStreak === 30) {
                embed.addFields({
                    name: '👑 Amazing Dedication!',
                    value: "You've maintained a 30-day streak! You're a true economy master!",
                    inline: false
                });
            }

            embed.setFooter({ 
                text: `Come back tomorrow to maintain your streak!` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in daily command:', error);
            await message.reply('❌ An error occurred while claiming your daily reward.');
        }
    }
};

