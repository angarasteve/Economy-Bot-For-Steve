/**
 * Gamble Command
 * Simple 50/50 gambling game
 */

const { createEmbed, createErrorEmbed, formatCurrency, getRandomNumber } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'gamble',
        description: 'Gamble your money in a 50/50 game',
        aliases: ['bet'],
        usage: '!gamble <amount>',
        category: 'economy',
        cooldown: 10
    },

    async execute(message, args, client) {
        if (args.length < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify an amount to gamble.\\n**Usage:** \`${client.config.prefix}gamble <amount>\`\\n**Example:** \`${client.config.prefix}gamble 100\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const userId = message.author.id;
        const amount = parseInt(args[0]);

        // Validate amount
        if (isNaN(amount) || amount < 10) {
            const embed = createErrorEmbed(
                '❌ Invalid Amount',
                'Please enter a valid amount (minimum 10 coins).'
            );
            return await message.reply({ embeds: [embed] });
        }

        if (amount > 10000) {
            const embed = createErrorEmbed(
                '❌ Amount Too Large',
                'Maximum gambling amount is 10,000 coins per bet.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Get user data
            const userData = await client.db.getUser(userId);

            // Check if user has enough money
            if (userData.balance < amount) {
                const embed = createErrorEmbed(
                    '💸 Insufficient Funds',
                    `You need ${formatCurrency(amount)} to place this bet.\\nYou currently have ${formatCurrency(userData.balance)}.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Generate random outcome (50/50 chance)
            const won = getRandomNumber(1, 100) <= 50;
            const winnings = won ? amount : -amount;

            // Update user balance
            await client.db.updateBalance(userId, winnings);

            // Create result embed
            const embed = createEmbed(
                won ? '🎉 You Won!' : '💸 You Lost!',
                '',
                won ? 0x00FF00 : 0xFF0000
            );

            embed.addFields(
                {
                    name: '🎲 Outcome',
                    value: won ? 'Winner! 🎊' : 'Better luck next time! 😢',
                    inline: true
                },
                {
                    name: '💰 Amount',
                    value: formatCurrency(amount),
                    inline: true
                },
                {
                    name: won ? '💎 Winnings' : '💸 Lost',
                    value: formatCurrency(Math.abs(winnings)),
                    inline: true
                },
                {
                    name: '💵 New Balance',
                    value: formatCurrency(userData.balance + winnings),
                    inline: false
                }
            );

            // Add motivational messages
            if (won) {
                embed.setDescription('🍀 Lady Luck is on your side today!');
            } else {
                embed.setDescription('🎰 The house always wins... sometimes!');
            }

            embed.setFooter({ 
                text: 'Gambling is risky! Only bet what you can afford to lose.' 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in gamble command:', error);
            await message.reply('❌ An error occurred while processing your bet.');
        }
    }
};

