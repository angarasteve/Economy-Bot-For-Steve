/**
 * Inventory Command
 * Display user's inventory items
 */

const { createEmbed, formatCurrency, paginate } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'inventory',
        description: 'View your or another user\'s inventory',
        aliases: ['inv', 'items'],
        usage: '!inventory [@user] [page]',
        category: 'economy',
        cooldown: 3
    },

    async execute(message, args, client) {
        // Get target user
        const target = message.mentions.users.first() || message.author;
        const isOwnInventory = target.id === message.author.id;
        
        // Get page number
        const page = parseInt(args.find(arg => !isNaN(parseInt(arg)))) || 1;

        try {
            // Get user inventory
            const inventory = await client.db.getUserInventory(target.id);

            if (!inventory || inventory.length === 0) {
                const embed = createEmbed(
                    `📦 ${isOwnInventory ? 'Your' : target.username + "'s"} Inventory`,
                    `${isOwnInventory ? 'Your inventory is empty!' : 'This user has no items.'}\\n\\nUse \`${client.config.prefix}shop\` to buy items!`,
                    0x0099FF
                );
                return await message.reply({ embeds: [embed] });
            }

            // Calculate total inventory value
            const totalValue = inventory.reduce((sum, item) => sum + (item.price * item.quantity), 0);

            // Paginate inventory (8 items per page)
            const pages = paginate(inventory, 8);
            const maxPages = pages.length;

            if (page < 1 || page > maxPages) {
                const embed = createEmbed(
                    '❌ Invalid Page',
                    `Please choose a page between 1 and ${maxPages}.`,
                    0xFF0000
                );
                return await message.reply({ embeds: [embed] });
            }

            const currentPageItems = pages[page - 1];

            // Create inventory embed
            const embed = createEmbed(
                `📦 ${isOwnInventory ? 'Your' : target.username + "'s"} Inventory`,
                `Page ${page}/${maxPages} • Total Items: ${inventory.length} • Total Value: ${formatCurrency(totalValue)}`,
                0x0099FF
            );

            // Add items to embed
            for (const item of currentPageItems) {
                const itemValue = item.price * item.quantity;
                embed.addFields({
                    name: `${item.emoji || '📦'} ${item.name}`,
                    value: `**Quantity:** ${item.quantity}\\n**Unit Value:** ${formatCurrency(item.price)}\\n**Total Value:** ${formatCurrency(itemValue)}`,
                    inline: true
                });
            }

            // Add sell instructions for own inventory
            if (isOwnInventory) {
                embed.addFields({
                    name: '💡 Selling Items',
                    value: `Use \`${client.config.prefix}sell <quantity> <item name>\` to sell items for 70% of their value.\\nExample: \`${client.config.prefix}sell 1 coffee\``,
                    inline: false
                });
            }

            if (target.displayAvatarURL) {
                embed.setThumbnail(target.displayAvatarURL({ dynamic: true }));
            }

            embed.setFooter({ 
                text: maxPages > 1 ? `Use ${client.config.prefix}inventory ${page + 1} for next page` : 'End of inventory' 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in inventory command:', error);
            await message.reply('❌ An error occurred while loading the inventory.');
        }
    }
};

