/**
 * Balance Command
 * Shows user's wallet and bank balance
 */

const { createEmbed, formatCurrency } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'balance',
        description: 'Check your or another user\'s balance',
        aliases: ['bal', 'money'],
        usage: '!balance [@user]',
        category: 'economy',
        cooldown: 3
    },

    async execute(message, args, client) {
        // Get target user (mentioned user or command author)
        const target = message.mentions.users.first() || message.author;
        const isOwnBalance = target.id === message.author.id;

        try {
            // Get user data from database
            const userData = await client.db.getUser(target.id);

            // Calculate total balance
            const totalBalance = userData.balance + userData.bank_balance;

            // Create embed
            const embed = createEmbed(
                `💰 ${isOwnBalance ? 'Your' : target.username + "'s"} Balance`,
                '',
                0x00FF00
            );

            embed.addFields(
                {
                    name: '💵 Wallet',
                    value: formatCurrency(userData.balance),
                    inline: true
                },
                {
                    name: '🏦 Bank',
                    value: formatCurrency(userData.bank_balance),
                    inline: true
                },
                {
                    name: '💎 Total',
                    value: formatCurrency(totalBalance),
                    inline: true
                },
                {
                    name: '📊 Statistics',
                    value: `**Level:** ${userData.level}\\n**Experience:** ${userData.experience}\\n**Daily Streak:** ${userData.daily_streak}`,
                    inline: false
                }
            );

            if (target.displayAvatarURL) {
                embed.setThumbnail(target.displayAvatarURL({ dynamic: true }));
            }

            embed.setFooter({ 
                text: `Use ${client.config.prefix}daily to claim your daily reward!` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in balance command:', error);
            await message.reply('❌ An error occurred while fetching balance data.');
        }
    }
};

