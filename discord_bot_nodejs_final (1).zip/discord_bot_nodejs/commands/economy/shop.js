/**
 * Shop Command
 * Display available items for purchase
 */

const { createEmbed, formatCurrency, paginate, capitalize } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'shop',
        description: 'Browse the shop items',
        aliases: ['store', 'market'],
        usage: '!shop [category] [page]',
        category: 'economy',
        cooldown: 3
    },

    async execute(message, args, client) {
        try {
            const category = args[0] ? args[0].toLowerCase() : null;
            const page = parseInt(args[1]) || 1;

            // Get shop items
            const items = await client.db.getShopItems(category);

            if (!items || items.length === 0) {
                const embed = createEmbed(
                    '🏪 Shop',
                    category ? `No items found in category: **${category}**` : 'No items available in the shop.',
                    0xFF0000
                );
                return await message.reply({ embeds: [embed] });
            }

            // Get unique categories for footer
            const allItems = await client.db.getShopItems();
            const categories = [...new Set(allItems.map(item => item.category))];

            // Paginate items (5 per page)
            const pages = paginate(items, 5);
            const maxPages = pages.length;

            if (page < 1 || page > maxPages) {
                const embed = createEmbed(
                    '❌ Invalid Page',
                    `Please choose a page between 1 and ${maxPages}.`,
                    0xFF0000
                );
                return await message.reply({ embeds: [embed] });
            }

            const currentPageItems = pages[page - 1];

            // Create shop embed
            const embed = createEmbed(
                `🏪 Shop${category ? ` - ${capitalize(category)}` : ''}`,
                `Page ${page}/${maxPages}`,
                0x0099FF
            );

            // Add items to embed
            for (const item of currentPageItems) {
                embed.addFields({
                    name: `${item.emoji || '📦'} ${item.name}`,
                    value: `${item.description}\\n**Price:** ${formatCurrency(item.price)}\\n**Category:** ${capitalize(item.category)}`,
                    inline: true
                });
            }

            // Add usage instructions
            embed.addFields({
                name: '💡 How to Buy',
                value: `Use \`${client.config.prefix}buy <quantity> <item name>\` to purchase items.\\nExample: \`${client.config.prefix}buy 1 coffee\``,
                inline: false
            });

            // Add categories info
            embed.addFields({
                name: '📂 Categories',
                value: categories.map(cat => capitalize(cat)).join(', '),
                inline: false
            });

            embed.setFooter({ 
                text: `Use ${client.config.prefix}shop <category> to filter by category` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in shop command:', error);
            await message.reply('❌ An error occurred while loading the shop.');
        }
    }
};

