/**
 * Buy Command
 * Purchase items from the shop
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, formatCurrency } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'buy',
        description: 'Buy items from the shop',
        aliases: ['purchase'],
        usage: '!buy <quantity> <item name>',
        category: 'economy',
        cooldown: 3
    },

    async execute(message, args, client) {
        if (args.length < 2) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify quantity and item name.\\n**Usage:** \`${client.config.prefix}buy <quantity> <item name>\`\\n**Example:** \`${client.config.prefix}buy 2 coffee\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const userId = message.author.id;
        const quantity = parseInt(args[0]);
        const itemName = args.slice(1).join(' ');

        // Validate quantity
        if (isNaN(quantity) || quantity < 1 || quantity > 100) {
            const embed = createErrorEmbed(
                '❌ Invalid Quantity',
                'Please enter a valid quantity between 1 and 100.'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Get user data
            const userData = await client.db.getUser(userId);

            // Find item in shop
            const item = await client.db.getItemByName(itemName);
            if (!item) {
                const embed = createErrorEmbed(
                    '❌ Item Not Found',
                    `The item "**${itemName}**" was not found in the shop.\\nUse \`${client.config.prefix}shop\` to see available items.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Calculate total cost
            const totalCost = item.price * quantity;

            // Check if user has enough money
            if (userData.balance < totalCost) {
                const embed = createErrorEmbed(
                    '💸 Insufficient Funds',
                    `You need ${formatCurrency(totalCost)} to buy ${quantity}x **${item.name}**.\\nYou currently have ${formatCurrency(userData.balance)}.\\nYou need ${formatCurrency(totalCost - userData.balance)} more.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Process purchase
            await client.db.updateBalance(userId, -totalCost);
            await client.db.addToInventory(userId, item.id, quantity);
            await client.db.run(
                'UPDATE users SET total_spent = total_spent + ? WHERE user_id = ?',
                [totalCost, userId]
            );

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Purchase Successful!',
                `You bought **${quantity}x ${item.name}** for ${formatCurrency(totalCost)}.`
            );

            embed.addFields(
                {
                    name: '🛍️ Item Details',
                    value: `${item.emoji || '📦'} **${item.name}**\\n${item.description}`,
                    inline: true
                },
                {
                    name: '💰 Transaction',
                    value: `**Quantity:** ${quantity}\\n**Unit Price:** ${formatCurrency(item.price)}\\n**Total Cost:** ${formatCurrency(totalCost)}`,
                    inline: true
                },
                {
                    name: '💵 Remaining Balance',
                    value: formatCurrency(userData.balance - totalCost),
                    inline: true
                }
            );

            embed.setFooter({ 
                text: `Use ${client.config.prefix}inventory to view your items!` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in buy command:', error);
            await message.reply('❌ An error occurred while processing your purchase.');
        }
    }
};

