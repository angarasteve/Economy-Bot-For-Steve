/**
 * Sell Command
 * Sell items from inventory for 70% of their value
 */

const { createEmbed, createErrorEmbed, createSuccessEmbed, formatCurrency } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'sell',
        description: 'Sell items from your inventory',
        aliases: ['sellitem'],
        usage: '!sell <quantity> <item name>',
        category: 'economy',
        cooldown: 3
    },

    async execute(message, args, client) {
        if (args.length < 2) {
            const embed = createErrorEmbed(
                '❌ Invalid Usage',
                `Please specify quantity and item name.\\n**Usage:** \`${client.config.prefix}sell <quantity> <item name>\`\\n**Example:** \`${client.config.prefix}sell 2 coffee\``
            );
            return await message.reply({ embeds: [embed] });
        }

        const userId = message.author.id;
        const quantity = parseInt(args[0]);
        const itemName = args.slice(1).join(' ');

        // Validate quantity
        if (isNaN(quantity) || quantity < 1) {
            const embed = createErrorEmbed(
                '❌ Invalid Quantity',
                'Please enter a valid quantity (minimum 1).'
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Find item in shop (to get price)
            const item = await client.db.getItemByName(itemName);
            if (!item) {
                const embed = createErrorEmbed(
                    '❌ Item Not Found',
                    `The item "**${itemName}**" was not found.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Check if item is sellable
            if (!item.sellable) {
                const embed = createErrorEmbed(
                    '❌ Cannot Sell',
                    `**${item.name}** cannot be sold.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Get user inventory
            const inventory = await client.db.getUserInventory(userId);
            const userItem = inventory.find(invItem => invItem.id === item.id);

            if (!userItem || userItem.quantity < quantity) {
                const embed = createErrorEmbed(
                    '❌ Insufficient Items',
                    `You don't have enough **${item.name}** to sell.\\n${userItem ? `You have: ${userItem.quantity}` : 'You have: 0'}\\nRequested: ${quantity}`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Calculate sell price (70% of original price)
            const sellPrice = Math.floor(item.price * 0.7);
            const totalEarnings = sellPrice * quantity;

            // Process sale
            await client.db.removeFromInventory(userId, item.id, quantity);
            await client.db.updateBalance(userId, totalEarnings);

            // Create success embed
            const embed = createSuccessEmbed(
                '✅ Sale Successful!',
                `You sold **${quantity}x ${item.name}** for ${formatCurrency(totalEarnings)}.`
            );

            embed.addFields(
                {
                    name: '🛍️ Item Details',
                    value: `${item.emoji || '📦'} **${item.name}**\\n${item.description}`,
                    inline: true
                },
                {
                    name: '💰 Transaction',
                    value: `**Quantity:** ${quantity}\\n**Unit Price:** ${formatCurrency(sellPrice)} (70% of ${formatCurrency(item.price)})\\n**Total Earned:** ${formatCurrency(totalEarnings)}`,
                    inline: true
                },
                {
                    name: '📦 Remaining',
                    value: `${userItem.quantity - quantity}x ${item.name}`,
                    inline: true
                }
            );

            embed.setFooter({ 
                text: `Use ${client.config.prefix}balance to check your updated balance!` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in sell command:', error);
            await message.reply('❌ An error occurred while processing your sale.');
        }
    }
};

