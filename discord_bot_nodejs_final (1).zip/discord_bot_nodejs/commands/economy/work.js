/**
 * Work Command
 * Earn money through various work scenarios
 */

const { createEmbed, createErrorEmbed, formatCurrency, getRandomNumber, getRandomElement } = require('../../utils/helpers');
const moment = require('moment');

module.exports = {
    data: {
        name: 'work',
        description: 'Work to earn money',
        aliases: ['job'],
        usage: '!work',
        category: 'economy',
        cooldown: 5
    },

    async execute(message, args, client) {
        const userId = message.author.id;

        try {
            // Get user data
            const userData = await client.db.getUser(userId);
            const now = moment();
            const lastWork = userData.last_work ? moment(userData.last_work) : null;

            // Check cooldown (1 hour)
            if (lastWork && now.diff(lastWork, 'minutes') < 60) {
                const timeLeft = 60 - now.diff(lastWork, 'minutes');
                const embed = createErrorEmbed(
                    '⏰ Work Cooldown',
                    `You need to rest! You can work again in **${timeLeft} minutes**.`
                );
                return await message.reply({ embeds: [embed] });
            }

            // Work scenarios with different pay ranges
            const workScenarios = [
                {
                    job: 'Software Developer',
                    description: 'You coded a new feature for a client',
                    emoji: '💻',
                    minPay: 150,
                    maxPay: 300
                },
                {
                    job: 'Pizza Delivery',
                    description: 'You delivered pizzas around the city',
                    emoji: '🍕',
                    minPay: 80,
                    maxPay: 150
                },
                {
                    job: 'Uber Driver',
                    description: 'You drove passengers to their destinations',
                    emoji: '🚗',
                    minPay: 100,
                    maxPay: 200
                },
                {
                    job: 'Freelance Writer',
                    description: 'You wrote articles for a blog',
                    emoji: '✍️',
                    minPay: 120,
                    maxPay: 250
                },
                {
                    job: 'Dog Walker',
                    description: 'You walked dogs in the neighborhood',
                    emoji: '🐕',
                    minPay: 60,
                    maxPay: 120
                },
                {
                    job: 'Graphic Designer',
                    description: 'You designed logos for small businesses',
                    emoji: '🎨',
                    minPay: 140,
                    maxPay: 280
                },
                {
                    job: 'Tutor',
                    description: 'You taught students online',
                    emoji: '📚',
                    minPay: 110,
                    maxPay: 220
                },
                {
                    job: 'Photographer',
                    description: 'You took photos at an event',
                    emoji: '📸',
                    minPay: 130,
                    maxPay: 260
                },
                {
                    job: 'Barista',
                    description: 'You served coffee at a local café',
                    emoji: '☕',
                    minPay: 70,
                    maxPay: 140
                },
                {
                    job: 'Mechanic',
                    description: 'You fixed cars at the garage',
                    emoji: '🔧',
                    minPay: 160,
                    maxPay: 320
                },
                {
                    job: 'Chef',
                    description: 'You cooked meals at a restaurant',
                    emoji: '👨‍🍳',
                    minPay: 120,
                    maxPay: 240
                },
                {
                    job: 'Gardener',
                    description: 'You maintained beautiful gardens',
                    emoji: '🌱',
                    minPay: 90,
                    maxPay: 180
                }
            ];

            // Select random work scenario
            const scenario = getRandomElement(workScenarios);
            const earnings = getRandomNumber(scenario.minPay, scenario.maxPay);

            // Level bonus (higher level = slightly better pay)
            const levelBonus = Math.floor(userData.level * 2);
            const totalEarnings = earnings + levelBonus;

            // Update user data
            await client.db.updateBalance(userId, totalEarnings);
            await client.db.run(
                'UPDATE users SET last_work = ?, total_earned = total_earned + ? WHERE user_id = ?',
                [now.toISOString(), totalEarnings, userId]
            );

            // Create success embed
            const embed = createEmbed(
                `${scenario.emoji} Work Complete!`,
                `**Job:** ${scenario.job}\\n${scenario.description}`,
                0x00FF00
            );

            embed.addFields(
                {
                    name: '💰 Base Pay',
                    value: formatCurrency(earnings),
                    inline: true
                },
                {
                    name: '⭐ Level Bonus',
                    value: formatCurrency(levelBonus),
                    inline: true
                },
                {
                    name: '💎 Total Earned',
                    value: formatCurrency(totalEarnings),
                    inline: true
                }
            );

            embed.setFooter({ 
                text: `You can work again in 1 hour. Use ${client.config.prefix}balance to check your money!` 
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in work command:', error);
            await message.reply('❌ An error occurred while working.');
        }
    }
};

