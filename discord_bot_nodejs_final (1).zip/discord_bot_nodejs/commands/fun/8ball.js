/**
 * 8Ball Command
 * Magic 8-ball fortune telling
 */

const { createEmbed, getRandomElement } = require('../../utils/helpers');

module.exports = {
    data: {
        name: '8ball',
        description: 'Ask the magic 8-ball a question',
        aliases: ['eightball', 'fortune'],
        usage: '!8ball <question>',
        category: 'fun',
        cooldown: 3
    },

    async execute(message, args, client) {
        if (args.length < 1) {
            const embed = createEmbed(
                '❌ No Question',
                `Please ask the magic 8-ball a question!\\n**Usage:** \`${client.config.prefix}8ball <question>\`\\n**Example:** \`${client.config.prefix}8ball Will I be rich?\``,
                0xFF0000
            );
            return await message.reply({ embeds: [embed] });
        }

        const question = args.join(' ');

        // Magic 8-ball responses
        const responses = [
            // Positive responses
            { text: 'It is certain', color: 0x00FF00, type: 'positive' },
            { text: 'It is decidedly so', color: 0x00FF00, type: 'positive' },
            { text: 'Without a doubt', color: 0x00FF00, type: 'positive' },
            { text: 'Yes definitely', color: 0x00FF00, type: 'positive' },
            { text: 'You may rely on it', color: 0x00FF00, type: 'positive' },
            { text: 'As I see it, yes', color: 0x00FF00, type: 'positive' },
            { text: 'Most likely', color: 0x00FF00, type: 'positive' },
            { text: 'Outlook good', color: 0x00FF00, type: 'positive' },
            { text: 'Yes', color: 0x00FF00, type: 'positive' },
            { text: 'Signs point to yes', color: 0x00FF00, type: 'positive' },
            
            // Neutral/uncertain responses
            { text: 'Reply hazy, try again', color: 0xFFFF00, type: 'neutral' },
            { text: 'Ask again later', color: 0xFFFF00, type: 'neutral' },
            { text: 'Better not tell you now', color: 0xFFFF00, type: 'neutral' },
            { text: 'Cannot predict now', color: 0xFFFF00, type: 'neutral' },
            { text: 'Concentrate and ask again', color: 0xFFFF00, type: 'neutral' },
            
            // Negative responses
            { text: "Don't count on it", color: 0xFF0000, type: 'negative' },
            { text: 'My reply is no', color: 0xFF0000, type: 'negative' },
            { text: 'My sources say no', color: 0xFF0000, type: 'negative' },
            { text: 'Outlook not so good', color: 0xFF0000, type: 'negative' },
            { text: 'Very doubtful', color: 0xFF0000, type: 'negative' },
            
            // Fun/creative responses
            { text: 'The stars say maybe', color: 0x9932CC, type: 'mystical' },
            { text: 'The universe is uncertain', color: 0x9932CC, type: 'mystical' },
            { text: 'Magic 8-ball is sleeping, try later', color: 0x808080, type: 'silly' },
            { text: 'Error 404: Answer not found', color: 0x808080, type: 'silly' },
            { text: 'The answer lies within you', color: 0x9932CC, type: 'mystical' },
            { text: 'That would be telling', color: 0xFFFF00, type: 'mysterious' },
            { text: 'The future is not set in stone', color: 0x9932CC, type: 'mystical' },
            { text: 'Ask your heart, not me', color: 0xFF69B4, type: 'philosophical' }
        ];

        const response = getRandomElement(responses);

        // Create response embed
        const embed = createEmbed(
            '🎱 Magic 8-Ball',
            '',
            response.color
        );

        embed.addFields(
            {
                name: '❓ Your Question',
                value: question,
                inline: false
            },
            {
                name: '🔮 The 8-Ball Says',
                value: `**"${response.text}"**`,
                inline: false
            }
        );

        // Add emoji based on response type
        let emoji = '🎱';
        switch (response.type) {
            case 'positive': emoji = '✅'; break;
            case 'negative': emoji = '❌'; break;
            case 'neutral': emoji = '❓'; break;
            case 'mystical': emoji = '🔮'; break;
            case 'silly': emoji = '🤪'; break;
            case 'mysterious': emoji = '🌟'; break;
            case 'philosophical': emoji = '🧠'; break;
        }

        embed.setThumbnail('https://cdn.discordapp.com/emojis/123456789012345678.png'); // You can add a custom 8-ball emoji URL here

        embed.setFooter({ 
            text: `${emoji} The magic 8-ball has spoken! • Asked by ${message.author.username}`,
            iconURL: message.author.displayAvatarURL({ dynamic: true })
        });

        await message.reply({ embeds: [embed] });
    }
};

