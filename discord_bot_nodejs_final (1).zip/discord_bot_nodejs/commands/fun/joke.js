/**
 * Joke Command
 * Tell random jokes from various categories
 */

const { createEmbed, getRandomElement } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'joke',
        description: 'Tell a random joke',
        aliases: ['funny', 'humor'],
        usage: '!joke [category]',
        category: 'fun',
        cooldown: 3
    },

    async execute(message, args, client) {
        const category = args[0] ? args[0].toLowerCase() : null;

        // Joke database organized by category
        const jokes = {
            programming: [
                {
                    setup: "Why do programmers prefer dark mode?",
                    punchline: "Because light attracts bugs!"
                },
                {
                    setup: "How many programmers does it take to change a light bulb?",
                    punchline: "None. That's a hardware problem."
                },
                {
                    setup: "Why do Java developers wear glasses?",
                    punchline: "Because they can't C#!"
                },
                {
                    setup: "What's a programmer's favorite hangout place?",
                    punchline: "Foo Bar!"
                },
                {
                    setup: "Why did the programmer quit his job?",
                    punchline: "He didn't get arrays!"
                }
            ],
            dad: [
                {
                    setup: "I'm reading a book about anti-gravity.",
                    punchline: "It's impossible to put down!"
                },
                {
                    setup: "Why don't scientists trust atoms?",
                    punchline: "Because they make up everything!"
                },
                {
                    setup: "What do you call a fake noodle?",
                    punchline: "An impasta!"
                },
                {
                    setup: "Why did the scarecrow win an award?",
                    punchline: "He was outstanding in his field!"
                },
                {
                    setup: "What do you call a bear with no teeth?",
                    punchline: "A gummy bear!"
                }
            ],
            animal: [
                {
                    setup: "What do you call a sleeping bull?",
                    punchline: "A bulldozer!"
                },
                {
                    setup: "Why don't elephants use computers?",
                    punchline: "They're afraid of the mouse!"
                },
                {
                    setup: "What do you call a fish wearing a crown?",
                    punchline: "A king fish!"
                },
                {
                    setup: "Why don't cats play poker in the jungle?",
                    punchline: "Too many cheetahs!"
                },
                {
                    setup: "What do you call a cow with no legs?",
                    punchline: "Ground beef!"
                }
            ],
            food: [
                {
                    setup: "Why did the tomato turn red?",
                    punchline: "Because it saw the salad dressing!"
                },
                {
                    setup: "What do you call cheese that isn't yours?",
                    punchline: "Nacho cheese!"
                },
                {
                    setup: "Why did the cookie go to the doctor?",
                    punchline: "Because it felt crumbly!"
                },
                {
                    setup: "What's orange and sounds like a parrot?",
                    punchline: "A carrot!"
                },
                {
                    setup: "Why don't eggs tell jokes?",
                    punchline: "They'd crack each other up!"
                }
            ],
            general: [
                {
                    setup: "Why don't skeletons fight each other?",
                    punchline: "They don't have the guts!"
                },
                {
                    setup: "What's the best thing about Switzerland?",
                    punchline: "I don't know, but the flag is a big plus!"
                },
                {
                    setup: "Why did the math book look so sad?",
                    punchline: "Because it had too many problems!"
                },
                {
                    setup: "What do you call a parade of rabbits hopping backwards?",
                    punchline: "A receding hare-line!"
                },
                {
                    setup: "Why can't a bicycle stand up by itself?",
                    punchline: "It's two tired!"
                }
            ]
        };

        // Get available categories
        const categories = Object.keys(jokes);

        // If category is specified but doesn't exist
        if (category && !categories.includes(category)) {
            const embed = createEmbed(
                '❌ Invalid Category',
                `Available categories: ${categories.map(cat => `\`${cat}\``).join(', ')}\\n\\nUse \`${client.config.prefix}joke\` for a random joke or \`${client.config.prefix}joke <category>\` for a specific category.`,
                0xFF0000
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Select joke
            let selectedCategory = category || getRandomElement(categories);
            const categoryJokes = jokes[selectedCategory];
            const joke = getRandomElement(categoryJokes);

            // Create joke embed
            const embed = createEmbed(
                `😂 ${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Joke`,
                '',
                getCategoryColor(selectedCategory)
            );

            embed.addFields(
                {
                    name: '🎭 Setup',
                    value: joke.setup,
                    inline: false
                },
                {
                    name: '🥁 Punchline',
                    value: joke.punchline,
                    inline: false
                }
            );

            // Add category emoji
            const categoryEmojis = {
                programming: '💻',
                dad: '👨',
                animal: '🐾',
                food: '🍕',
                general: '😄'
            };

            embed.setThumbnail(`https://cdn.discordapp.com/emojis/123456789012345678.png`); // You can add custom emoji URLs

            embed.setFooter({ 
                text: `${categoryEmojis[selectedCategory] || '😄'} Hope that made you smile! • Use ${client.config.prefix}joke for another one`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in joke command:', error);
            await message.reply('❌ An error occurred while fetching a joke. That\'s not very funny! 😅');
        }
    }
};

/**
 * Get color based on joke category
 */
function getCategoryColor(category) {
    const colors = {
        programming: 0x00FF00,
        dad: 0xFFAA00,
        animal: 0x8B4513,
        food: 0xFF69B4,
        general: 0x0099FF
    };
    return colors[category] || 0x0099FF;
}

