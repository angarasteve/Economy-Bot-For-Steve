/**
 * Dice Command
 * Roll various types of dice
 */

const { createEmbed, createErrorEmbed, getRandomNumber } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'dice',
        description: 'Roll dice with various configurations',
        aliases: ['roll', 'd'],
        usage: '!dice [number]d[sides] or !dice [sides]',
        category: 'fun',
        cooldown: 2
    },

    async execute(message, args, client) {
        let numDice = 1;
        let numSides = 6;

        if (args.length > 0) {
            const input = args[0].toLowerCase();

            // Check for standard dice notation (e.g., 2d6, 3d20)
            if (input.includes('d')) {
                const parts = input.split('d');
                if (parts.length === 2) {
                    const dice = parseInt(parts[0]) || 1;
                    const sides = parseInt(parts[1]);

                    if (dice < 1 || dice > 20) {
                        const embed = createErrorEmbed(
                            '❌ Invalid Number of Dice',
                            'Please specify between 1 and 20 dice.'
                        );
                        return await message.reply({ embeds: [embed] });
                    }

                    if (sides < 2 || sides > 1000) {
                        const embed = createErrorEmbed(
                            '❌ Invalid Number of Sides',
                            'Please specify between 2 and 1000 sides.'
                        );
                        return await message.reply({ embeds: [embed] });
                    }

                    numDice = dice;
                    numSides = sides;
                }
            } else {
                // Just a number of sides
                const sides = parseInt(input);
                if (sides && sides >= 2 && sides <= 1000) {
                    numSides = sides;
                } else {
                    const embed = createErrorEmbed(
                        '❌ Invalid Input',
                        'Please use format: `2d6` (2 dice with 6 sides) or just `20` (1 die with 20 sides).\\n\\n**Examples:**\\n• `!dice` - Roll 1d6\\n• `!dice 20` - Roll 1d20\\n• `!dice 3d8` - Roll 3d8'
                    );
                    return await message.reply({ embeds: [embed] });
                }
            }
        }

        try {
            // Roll the dice
            const rolls = [];
            let total = 0;

            for (let i = 0; i < numDice; i++) {
                const roll = getRandomNumber(1, numSides);
                rolls.push(roll);
                total += roll;
            }

            // Create result embed
            const embed = createEmbed(
                `🎲 Dice Roll: ${numDice}d${numSides}`,
                '',
                getDiceColor(total, numDice, numSides)
            );

            // Show individual rolls if multiple dice
            if (numDice > 1) {
                embed.addFields(
                    {
                        name: '🎯 Individual Rolls',
                        value: rolls.map((roll, index) => `Die ${index + 1}: **${roll}**`).join('\\n'),
                        inline: true
                    },
                    {
                        name: '📊 Total',
                        value: `**${total}**`,
                        inline: true
                    },
                    {
                        name: '📈 Statistics',
                        value: `**Average:** ${(total / numDice).toFixed(1)}\\n**Min Possible:** ${numDice}\\n**Max Possible:** ${numDice * numSides}`,
                        inline: true
                    }
                );
            } else {
                embed.addFields(
                    {
                        name: '🎯 Result',
                        value: `**${total}**`,
                        inline: true
                    },
                    {
                        name: '📊 Range',
                        value: `1 - ${numSides}`,
                        inline: true
                    }
                );

                // Add special messages for common dice
                if (numSides === 6 && total === 6) {
                    embed.addFields({
                        name: '🎉 Special',
                        value: 'Natural 6! 🔥',
                        inline: true
                    });
                } else if (numSides === 20 && total === 20) {
                    embed.addFields({
                        name: '🎉 Special',
                        value: 'Natural 20! Critical Success! ⚡',
                        inline: true
                    });
                } else if (numSides === 20 && total === 1) {
                    embed.addFields({
                        name: '💀 Special',
                        value: 'Natural 1! Critical Failure! 💥',
                        inline: true
                    });
                }
            }

            // Add visual representation for small numbers
            if (numDice === 1 && numSides <= 6) {
                const diceEmojis = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
                embed.setDescription(`${diceEmojis[total]} **${total}**`);
            }

            embed.setFooter({ 
                text: `Rolled by ${message.author.username} • Use !dice 2d6 for multiple dice`,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            });

            await message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in dice command:', error);
            await message.reply('❌ An error occurred while rolling the dice.');
        }
    }
};

/**
 * Get color based on dice roll result
 */
function getDiceColor(total, numDice, numSides) {
    const maxPossible = numDice * numSides;
    const percentage = total / maxPossible;

    if (percentage >= 0.9) return 0x00FF00; // Green for high rolls
    if (percentage >= 0.7) return 0xFFFF00; // Yellow for good rolls
    if (percentage >= 0.3) return 0x0099FF; // Blue for average rolls
    if (percentage >= 0.1) return 0xFF8C00; // Orange for low rolls
    return 0xFF0000; // Red for very low rolls
}

