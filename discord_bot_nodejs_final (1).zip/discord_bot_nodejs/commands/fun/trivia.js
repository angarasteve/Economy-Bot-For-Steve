/**
 * Trivia Command
 * Interactive trivia game with multiple categories
 */

const { createEmbed, createSuccessEmbed, createErrorEmbed, getRandomElement } = require('../../utils/helpers');

module.exports = {
    data: {
        name: 'trivia',
        description: 'Play a trivia game with multiple categories',
        aliases: ['quiz', 'question'],
        usage: '!trivia [category]',
        category: 'fun',
        cooldown: 5
    },

    async execute(message, args, client) {
        const category = args[0] ? args[0].toLowerCase() : null;

        // Trivia questions database
        const triviaQuestions = {
            general: [
                {
                    question: "What is the capital of France?",
                    options: ["London", "Berlin", "Paris", "Madrid"],
                    correct: 2,
                    difficulty: "easy"
                },
                {
                    question: "Which planet is known as the Red Planet?",
                    options: ["Venus", "Mars", "Jupiter", "Saturn"],
                    correct: 1,
                    difficulty: "easy"
                },
                {
                    question: "What is the largest mammal in the world?",
                    options: ["African Elephant", "Blue Whale", "Giraffe", "Polar Bear"],
                    correct: 1,
                    difficulty: "medium"
                },
                {
                    question: "In which year did World War II end?",
                    options: ["1944", "1945", "1946", "1947"],
                    correct: 1,
                    difficulty: "medium"
                },
                {
                    question: "What is the chemical symbol for gold?",
                    options: ["Go", "Gd", "Au", "Ag"],
                    correct: 2,
                    difficulty: "hard"
                }
            ],
            science: [
                {
                    question: "What is the speed of light in vacuum?",
                    options: ["299,792,458 m/s", "300,000,000 m/s", "299,000,000 m/s", "301,000,000 m/s"],
                    correct: 0,
                    difficulty: "hard"
                },
                {
                    question: "Which element has the atomic number 1?",
                    options: ["Helium", "Hydrogen", "Lithium", "Carbon"],
                    correct: 1,
                    difficulty: "easy"
                },
                {
                    question: "What is the powerhouse of the cell?",
                    options: ["Nucleus", "Ribosome", "Mitochondria", "Endoplasmic Reticulum"],
                    correct: 2,
                    difficulty: "medium"
                },
                {
                    question: "What type of bond involves the sharing of electrons?",
                    options: ["Ionic", "Covalent", "Metallic", "Hydrogen"],
                    correct: 1,
                    difficulty: "medium"
                }
            ],
            history: [
                {
                    question: "Who was the first President of the United States?",
                    options: ["Thomas Jefferson", "John Adams", "George Washington", "Benjamin Franklin"],
                    correct: 2,
                    difficulty: "easy"
                },
                {
                    question: "In which year did the Berlin Wall fall?",
                    options: ["1987", "1988", "1989", "1990"],
                    correct: 2,
                    difficulty: "medium"
                },
                {
                    question: "Which ancient wonder of the world was located in Alexandria?",
                    options: ["Hanging Gardens", "Lighthouse", "Colossus", "Mausoleum"],
                    correct: 1,
                    difficulty: "hard"
                }
            ],
            gaming: [
                {
                    question: "Which company created the game 'Minecraft'?",
                    options: ["Microsoft", "Mojang", "Sony", "Nintendo"],
                    correct: 1,
                    difficulty: "easy"
                },
                {
                    question: "What is the highest-selling video game of all time?",
                    options: ["Tetris", "Minecraft", "Grand Theft Auto V", "Wii Sports"],
                    correct: 1,
                    difficulty: "medium"
                },
                {
                    question: "In which year was the first PlayStation console released?",
                    options: ["1994", "1995", "1996", "1997"],
                    correct: 1,
                    difficulty: "hard"
                }
            ]
        };

        // Get available categories
        const categories = Object.keys(triviaQuestions);

        // If category is specified but doesn't exist
        if (category && !categories.includes(category)) {
            const embed = createErrorEmbed(
                '❌ Invalid Category',
                `Available categories: ${categories.map(cat => `\`${cat}\``).join(', ')}\\n\\nUse \`${client.config.prefix}trivia\` for a random question or \`${client.config.prefix}trivia <category>\` for a specific category.`
            );
            return await message.reply({ embeds: [embed] });
        }

        try {
            // Select question
            let selectedCategory = category || getRandomElement(categories);
            const questions = triviaQuestions[selectedCategory];
            const question = getRandomElement(questions);

            // Create trivia embed
            const embed = createEmbed(
                `🧠 Trivia - ${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}`,
                question.question,
                getDifficultyColor(question.difficulty)
            );

            // Add options
            const optionEmojis = ['🇦', '🇧', '🇨', '🇩'];
            const optionsText = question.options
                .map((option, index) => `${optionEmojis[index]} ${option}`)
                .join('\\n');

            embed.addFields(
                {
                    name: '📝 Options',
                    value: optionsText,
                    inline: false
                },
                {
                    name: '⚡ Difficulty',
                    value: question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1),
                    inline: true
                },
                {
                    name: '⏰ Time Limit',
                    value: '30 seconds',
                    inline: true
                }
            );

            embed.setFooter({ 
                text: 'React with the corresponding emoji to answer!' 
            });

            const triviaMessage = await message.reply({ embeds: [embed] });

            // Add reaction options
            for (let i = 0; i < question.options.length; i++) {
                await triviaMessage.react(optionEmojis[i]);
            }

            // Create reaction collector
            const filter = (reaction, user) => {
                return optionEmojis.includes(reaction.emoji.name) && user.id === message.author.id;
            };

            const collector = triviaMessage.createReactionCollector({ 
                filter, 
                time: 30000, 
                max: 1 
            });

            collector.on('collect', (reaction) => {
                const selectedIndex = optionEmojis.indexOf(reaction.emoji.name);
                const isCorrect = selectedIndex === question.correct;

                // Create result embed
                const resultEmbed = isCorrect 
                    ? createSuccessEmbed('🎉 Correct!', `Great job! The answer was **${question.options[question.correct]}**.`)
                    : createErrorEmbed('❌ Incorrect!', `The correct answer was **${question.options[question.correct]}**.`);

                resultEmbed.addFields({
                    name: '📊 Your Answer',
                    value: `${optionEmojis[selectedIndex]} ${question.options[selectedIndex]}`,
                    inline: true
                });

                if (isCorrect) {
                    // Award points based on difficulty
                    const points = { easy: 10, medium: 20, hard: 30 }[question.difficulty];
                    resultEmbed.addFields({
                        name: '💰 Points Earned',
                        value: `+${points} coins`,
                        inline: true
                    });

                    // Add points to user's balance
                    client.db.updateBalance(message.author.id, points).catch(console.error);
                }

                resultEmbed.setFooter({ 
                    text: `Use ${client.config.prefix}trivia to play again!` 
                });

                triviaMessage.edit({ embeds: [resultEmbed] });
                triviaMessage.reactions.removeAll().catch(console.error);
            });

            collector.on('end', (collected) => {
                if (collected.size === 0) {
                    // Time's up
                    const timeoutEmbed = createErrorEmbed(
                        '⏰ Time\'s Up!',
                        `The correct answer was **${question.options[question.correct]}**.`
                    );
                    timeoutEmbed.setFooter({ 
                        text: `Use ${client.config.prefix}trivia to try again!` 
                    });

                    triviaMessage.edit({ embeds: [timeoutEmbed] });
                    triviaMessage.reactions.removeAll().catch(console.error);
                }
            });

        } catch (error) {
            console.error('Error in trivia command:', error);
            await message.reply('❌ An error occurred while loading the trivia question.');
        }
    }
};

/**
 * Get color based on difficulty
 */
function getDifficultyColor(difficulty) {
    switch (difficulty) {
        case 'easy': return 0x00FF00;
        case 'medium': return 0xFFFF00;
        case 'hard': return 0xFF0000;
        default: return 0x0099FF;
    }
}

