/**
 * Discord Economy Bot - Node.js Edition
 * A comprehensive Discord bot with economy, moderation, fun commands, and more
 * 
 * @author Manus AI
 * @version 2.0.0
 */

require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Events, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const figlet = require('figlet');
const Database = require('./database/Database');

// Create Discord client with necessary intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages
    ]
});

// Initialize collections for commands and cooldowns
client.commands = new Collection();
client.cooldowns = new Collection();

// Initialize database
client.db = new Database();

// Bot configuration
client.config = {
    prefix: process.env.PREFIX || '!',
    ownerId: process.env.OWNER_ID || '',
    version: '2.0.0',
    startTime: Date.now()
};

/**
 * Load all commands from the commands directory
 */
function loadCommands() {
    const commandsPath = path.join(__dirname, 'commands');
    const commandFolders = fs.readdirSync(commandsPath);

    let commandCount = 0;

    for (const folder of commandFolders) {
        const commandsDir = path.join(commandsPath, folder);
        if (!fs.statSync(commandsDir).isDirectory()) continue;

        const commandFiles = fs.readdirSync(commandsDir).filter(file => file.endsWith('.js'));

        for (const file of commandFiles) {
            const filePath = path.join(commandsDir, file);
            try {
                const command = require(filePath);
                
                if ('data' in command && 'execute' in command) {
                    client.commands.set(command.data.name, command);
                    commandCount++;
                    console.log(chalk.green(`✓ Loaded command: ${command.data.name} (${folder})`));
                } else {
                    console.log(chalk.yellow(`⚠ Command at ${filePath} is missing required "data" or "execute" property`));
                }
            } catch (error) {
                console.log(chalk.red(`✗ Error loading command ${file}:`), error.message);
            }
        }
    }

    console.log(chalk.blue(`📦 Loaded ${commandCount} commands from ${commandFolders.length} categories`));
}

/**
 * Load all event handlers from the events directory
 */
function loadEvents() {
    const eventsPath = path.join(__dirname, 'events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        try {
            const event = require(filePath);
            
            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args, client));
            } else {
                client.on(event.name, (...args) => event.execute(...args, client));
            }
            
            console.log(chalk.green(`✓ Loaded event: ${event.name}`));
        } catch (error) {
            console.log(chalk.red(`✗ Error loading event ${file}:`), error.message);
        }
    }
}

/**
 * Display startup banner
 */
function displayBanner() {
    console.clear();
    console.log(chalk.cyan(figlet.textSync('Discord Bot', { horizontalLayout: 'full' })));
    console.log(chalk.yellow('═'.repeat(80)));
    console.log(chalk.green('🤖 Discord Economy Bot - Node.js Edition'));
    console.log(chalk.green('📦 Version: 2.0.0'));
    console.log(chalk.green('👨‍💻 Created by: Manus AI'));
    console.log(chalk.yellow('═'.repeat(80)));
}

/**
 * Bot ready event
 */
client.once(Events.ClientReady, async (readyClient) => {
    console.log(chalk.green(`✅ Bot is ready! Logged in as ${readyClient.user.tag}`));
    console.log(chalk.blue(`🌐 Serving ${readyClient.guilds.cache.size} servers`));
    console.log(chalk.blue(`👥 Watching ${readyClient.users.cache.size} users`));
    
    // Set bot activity
    client.user.setActivity('!help | Economy & Fun', { type: ActivityType.Playing });
    
    // Initialize database
    try {
        await client.db.initialize();
        console.log(chalk.green('✅ Database initialized successfully'));
    } catch (error) {
        console.error(chalk.red('❌ Database initialization failed:'), error);
    }
    
    console.log(chalk.yellow('═'.repeat(80)));
    console.log(chalk.green('🚀 Bot is fully operational!'));
});

/**
 * Message create event for command handling
 */
client.on(Events.MessageCreate, async (message) => {
    // Ignore bot messages and messages without prefix
    if (message.author.bot || !message.content.startsWith(client.config.prefix)) return;

    const args = message.content.slice(client.config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    // Find command (including aliases)
    const command = client.commands.get(commandName) || 
                   client.commands.find(cmd => cmd.data.aliases && cmd.data.aliases.includes(commandName));

    if (!command) return;

    // Check cooldowns
    const { cooldowns } = client;
    if (!cooldowns.has(command.data.name)) {
        cooldowns.set(command.data.name, new Collection());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.data.name);
    const cooldownAmount = (command.data.cooldown || 3) * 1000;

    if (timestamps.has(message.author.id)) {
        const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

        if (now < expirationTime) {
            const timeLeft = (expirationTime - now) / 1000;
            return message.reply(`⏰ Please wait ${timeLeft.toFixed(1)} more seconds before using \`${command.data.name}\` again.`);
        }
    }

    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

    // Execute command
    try {
        await command.execute(message, args, client);
    } catch (error) {
        console.error(chalk.red(`Error executing command ${command.data.name}:`), error);
        
        const errorMessage = 'There was an error while executing this command!';
        if (message.replied || message.deferred) {
            await message.followUp({ content: errorMessage, ephemeral: true });
        } else {
            await message.reply(errorMessage);
        }
    }
});

/**
 * Error handling
 */
client.on(Events.Error, error => {
    console.error(chalk.red('Discord client error:'), error);
});

process.on('unhandledRejection', error => {
    console.error(chalk.red('Unhandled promise rejection:'), error);
});

process.on('uncaughtException', error => {
    console.error(chalk.red('Uncaught exception:'), error);
    process.exit(1);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log(chalk.yellow('\\n🛑 Received SIGINT. Shutting down gracefully...'));
    client.destroy();
    process.exit(0);
});

// Initialize bot
async function startBot() {
    displayBanner();
    
    console.log(chalk.blue('🔄 Loading commands...'));
    loadCommands();
    
    console.log(chalk.blue('🔄 Loading events...'));
    loadEvents();
    
    console.log(chalk.blue('🔄 Connecting to Discord...'));
    
    // Login to Discord
    try {
        await client.login(process.env.DISCORD_TOKEN);
    } catch (error) {
        console.error(chalk.red('❌ Failed to login to Discord:'), error.message);
        process.exit(1);
    }
}

// Start the bot
startBot();

