/**
 * Message Reaction Remove Event
 * Handle reaction role removal
 */

const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageReactionRemove,
    async execute(reaction, user, client) {
        // Ignore bot reactions
        if (user.bot) return;

        // Handle partial reactions
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                console.error('Something went wrong when fetching the reaction:', error);
                return;
            }
        }

        try {
            // Check for reaction roles
            const emoji = reaction.emoji.name || reaction.emoji.toString();
            const reactionRole = await client.db.get(
                'SELECT * FROM role_reactions WHERE message_id = ? AND emoji = ?',
                [reaction.message.id, emoji]
            );

            if (reactionRole) {
                const guild = reaction.message.guild;
                const member = await guild.members.fetch(user.id);
                const role = guild.roles.cache.get(reactionRole.role_id);

                if (role && member && member.roles.cache.has(role.id)) {
                    try {
                        await member.roles.remove(role);
                        console.log(`Removed role ${role.name} from ${user.username} via reaction role`);
                        
                        // Try to send DM notification
                        try {
                            await user.send(`❌ The **${role.name}** role has been removed from you in **${guild.name}**.`);
                        } catch (error) {
                            // User has DMs disabled, ignore
                        }
                    } catch (error) {
                        console.error('Error removing role via reaction:', error);
                    }
                }
            }

        } catch (error) {
            console.error('Error in messageReactionRemove event:', error);
        }
    },
};

