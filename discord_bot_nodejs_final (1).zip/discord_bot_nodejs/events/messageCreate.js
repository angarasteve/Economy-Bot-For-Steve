/**
 * Message Create Event
 * Handle auto reactions and other message-based features
 */

const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageCreate,
    async execute(message, client) {
        // Ignore bot messages
        if (message.author.bot) return;

        // Handle auto reactions
        try {
            const autoReacts = await client.db.all(
                'SELECT * FROM auto_reactions WHERE guild_id = ? AND enabled = 1',
                [message.guild?.id]
            );

            for (const autoReact of autoReacts) {
                let shouldReact = false;

                switch (autoReact.trigger_type) {
                    case 'keyword':
                        shouldReact = message.content.toLowerCase().includes(autoReact.trigger_value.toLowerCase());
                        break;
                    
                    case 'exact':
                        shouldReact = message.content.toLowerCase() === autoReact.trigger_value.toLowerCase();
                        break;
                    
                    case 'starts':
                        shouldReact = message.content.toLowerCase().startsWith(autoReact.trigger_value.toLowerCase());
                        break;
                    
                    case 'ends':
                        shouldReact = message.content.toLowerCase().endsWith(autoReact.trigger_value.toLowerCase());
                        break;
                    
                    case 'user':
                        shouldReact = message.author.id === autoReact.trigger_value;
                        break;
                    
                    case 'channel':
                        shouldReact = message.channel.id === autoReact.trigger_value;
                        break;
                }

                if (shouldReact) {
                    try {
                        await message.react(autoReact.emoji);
                        
                        // Update usage count
                        await client.db.run(
                            'UPDATE auto_reactions SET uses = uses + 1 WHERE id = ?',
                            [autoReact.id]
                        );
                    } catch (error) {
                        console.error(`Failed to react with ${autoReact.emoji}:`, error);
                    }
                }
            }
        } catch (error) {
            console.error('Error processing auto reactions:', error);
        }
    },
};

