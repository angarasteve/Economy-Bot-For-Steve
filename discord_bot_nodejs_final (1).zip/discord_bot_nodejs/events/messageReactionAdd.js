/**
 * Message Reaction Add Event
 * Handle reaction roles and other reaction-based features
 */

const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageReactionAdd,
    async execute(reaction, user, client) {
        // Ignore bot reactions
        if (user.bot) return;

        // Handle partial reactions
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                console.error('Something went wrong when fetching the reaction:', error);
                return;
            }
        }

        try {
            // Check for reaction roles
            const emoji = reaction.emoji.name || reaction.emoji.toString();
            const reactionRole = await client.db.get(
                'SELECT * FROM role_reactions WHERE message_id = ? AND emoji = ?',
                [reaction.message.id, emoji]
            );

            if (reactionRole) {
                const guild = reaction.message.guild;
                const member = await guild.members.fetch(user.id);
                const role = guild.roles.cache.get(reactionRole.role_id);

                if (role && member && !member.roles.cache.has(role.id)) {
                    try {
                        await member.roles.add(role);
                        console.log(`Added role ${role.name} to ${user.username} via reaction role`);
                        
                        // Try to send DM notification
                        try {
                            await user.send(`✅ You have been given the **${role.name}** role in **${guild.name}**!`);
                        } catch (error) {
                            // User has DMs disabled, ignore
                        }
                    } catch (error) {
                        console.error('Error adding role via reaction:', error);
                    }
                }
            }

        } catch (error) {
            console.error('Error in messageReactionAdd event:', error);
        }
    },
};

