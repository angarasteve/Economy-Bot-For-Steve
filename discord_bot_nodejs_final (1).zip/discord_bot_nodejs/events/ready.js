/**
 * Ready Event Handler
 * Triggered when the bot successfully connects to Discord
 */

const { Events } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);
        
        // Set initial activity
        client.user.setActivity('!help | Node.js Edition', { type: 'PLAYING' });
        
        // Log some statistics
        console.log(`Serving ${client.guilds.cache.size} servers`);
        console.log(`Watching ${client.users.cache.size} users`);
    },
};

