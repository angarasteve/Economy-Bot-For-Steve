# Discord Economy Bot - Node.js Edition

A comprehensive Discord bot built with Node.js featuring economy system, moderation tools, fun commands, role management, auto-reactions, and advanced giveaways with ticket system.

## 🌟 Features

### 💰 Economy System
- **Balance Management**: Check, transfer, and manage user balances
- **Daily Rewards**: Claim daily coins with streak bonuses
- **Work System**: Earn coins through various job activities
- **Shop & Inventory**: Buy, sell, and manage items
- **Gambling**: Risk coins for potential rewards

### 🛡️ Moderation Tools
- **Member Management**: Kick, ban, and timeout users
- **Message Management**: Clear messages in bulk
- **Permission Checks**: Role hierarchy and permission validation
- **Audit Logging**: Track moderation actions

### 🎮 Fun Commands
- **8-Ball**: Magic 8-ball fortune telling with varied responses
- **Dice Rolling**: Advanced dice system supporting multiple dice and sides
- **Trivia Game**: Interactive trivia with multiple categories and difficulties
- **Jokes**: Categorized joke system with programming, dad jokes, and more

### 🔧 Utility Commands
- **User Information**: Detailed user profiles with roles and permissions
- **Server Information**: Comprehensive server statistics and features
- **Calculator**: Safe mathematical expression evaluation
- **Help System**: Dynamic command documentation

### 🎭 Role Management
- **Role Assignment**: Add/remove roles with hierarchy checks
- **Reaction Roles**: Automatic role assignment via message reactions
- **Permission Validation**: Ensure proper role management permissions

### 🤖 Auto-React System
- **Trigger Types**: Keyword, exact match, starts/ends with, user-specific, channel-specific
- **Management**: Add, remove, toggle, and list auto-reactions
- **Usage Statistics**: Track reaction usage and performance

### 🎁 Advanced Giveaways
- **Ticket System**: Private channels created for winners
- **Auto-Reroll**: Automatic winner reselection if no response within 24 hours
- **Multiple Winners**: Support for multiple winners per giveaway
- **Deadline Management**: Automated deadline tracking and enforcement

## 📋 Command List

### Economy Commands (9)
- `!balance [@user]` - Check coin balance
- `!daily` - Claim daily reward
- `!work` - Work for coins
- `!shop` - View available items
- `!buy <item>` - Purchase an item
- `!inventory` - View your items
- `!sell <item>` - Sell an item
- `!pay <@user> <amount>` - Transfer coins
- `!gamble <amount>` - Gamble coins

### Moderation Commands (4)
- `!kick <@user> [reason]` - Kick a member
- `!ban <@user> [reason]` - Ban a member
- `!timeout <@user> <duration> [reason]` - Timeout a member
- `!clear <amount>` - Clear messages

### Fun Commands (4)
- `!8ball <question>` - Ask the magic 8-ball
- `!dice [dice notation]` - Roll dice (supports 1d6, 2d20, etc.)
- `!trivia [category]` - Play trivia game
- `!joke [category]` - Tell a random joke

### Utility Commands (4)
- `!userinfo [@user]` - Get user information
- `!serverinfo` - Get server information
- `!calculator <expression>` - Calculate math expressions
- `!help [command/category]` - Show help information

### Role Commands (2)
- `!role <add/remove> <@user> <role>` - Manage user roles
- `!reactionrole <add/remove/list> [args]` - Manage reaction roles

### Auto-React Commands (1)
- `!autoreact <add/remove/list/toggle> [args]` - Manage auto-reactions

### Giveaway Commands (1)
- `!giveaway <duration> <winners> <prize>` - Create advanced giveaway

**Total Commands: 25**

## 🚀 Installation & Setup

### Prerequisites
- Node.js 18.0.0 or higher
- npm or yarn package manager
- Discord Bot Token

### Step 1: Clone and Install
```bash
git clone <repository-url>
cd discord_bot_nodejs
npm install
```

### Step 2: Configuration
1. Copy `.env.example` to `.env`
2. Fill in your bot token and other settings:
```env
DISCORD_TOKEN=your_bot_token_here
PREFIX=!
OWNER_ID=your_user_id
```

### Step 3: Database Setup
The bot automatically creates and initializes the SQLite database on first run.

### Step 4: Run the Bot
```bash
npm start
```

## ⚙️ Configuration

### Environment Variables
- `DISCORD_TOKEN` - Your Discord bot token (required)
- `PREFIX` - Command prefix (default: !)
- `OWNER_ID` - Bot owner's Discord user ID
- `NODE_ENV` - Environment (development/production)

### Bot Permissions
The bot requires the following permissions:
- Send Messages
- Embed Links
- Add Reactions
- Manage Messages
- Manage Roles
- Kick Members
- Ban Members
- Moderate Members
- Manage Channels (for giveaway tickets)

### Invite Link
```
https://discord.com/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=1099511627775&scope=bot
```

## 🗄️ Database Schema

The bot uses SQLite with the following tables:

### Users Table
```sql
CREATE TABLE users (
    id TEXT PRIMARY KEY,
    balance INTEGER DEFAULT 0,
    daily_last TEXT,
    daily_streak INTEGER DEFAULT 0
);
```

### User Items Table
```sql
CREATE TABLE user_items (
    user_id TEXT,
    item_name TEXT,
    quantity INTEGER DEFAULT 1,
    PRIMARY KEY (user_id, item_name)
);
```

### Role Reactions Table
```sql
CREATE TABLE role_reactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    message_id TEXT,
    emoji TEXT,
    role_id TEXT
);
```

### Auto Reactions Table
```sql
CREATE TABLE auto_reactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    trigger_type TEXT,
    trigger_value TEXT,
    emoji TEXT,
    enabled INTEGER DEFAULT 1,
    uses INTEGER DEFAULT 0
);
```

### Giveaways Table
```sql
CREATE TABLE giveaways (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT,
    channel_id TEXT,
    message_id TEXT,
    title TEXT,
    prize TEXT,
    winner_count INTEGER,
    end_time TEXT,
    host_id TEXT,
    ended INTEGER DEFAULT 0
);
```

### Giveaway Entries Table
```sql
CREATE TABLE giveaway_entries (
    giveaway_id INTEGER,
    user_id TEXT,
    PRIMARY KEY (giveaway_id, user_id)
);
```

### Giveaway Winners Table
```sql
CREATE TABLE giveaway_winners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    giveaway_id INTEGER,
    user_id TEXT,
    ticket_channel_id TEXT,
    claim_deadline TEXT,
    claimed INTEGER DEFAULT 0
);
```

## 🔧 Development

### Project Structure
```
discord_bot_nodejs/
├── commands/
│   ├── economy/          # Economy commands
│   ├── moderation/       # Moderation commands
│   ├── fun/             # Fun commands
│   ├── utility/         # Utility commands
│   ├── roles/           # Role management commands
│   ├── autoreact/       # Auto-react commands
│   └── giveaway/        # Giveaway commands
├── events/              # Event handlers
├── utils/               # Utility functions
├── database/            # Database connection and models
├── config/              # Configuration files
└── index.js            # Main bot file
```

### Adding New Commands
1. Create a new file in the appropriate command category folder
2. Follow the command template structure:
```javascript
module.exports = {
    data: {
        name: 'commandname',
        description: 'Command description',
        aliases: ['alias1', 'alias2'],
        usage: '!commandname <args>',
        category: 'category',
        cooldown: 3
    },
    async execute(message, args, client) {
        // Command logic here
    }
};
```

### Event Handling
Events are automatically loaded from the `events/` folder. Each event file should export:
```javascript
module.exports = {
    name: Events.EventName,
    async execute(eventData, client) {
        // Event logic here
    }
};
```

## 🛠️ Troubleshooting

### Common Issues

**Bot not responding to commands:**
- Check if the bot has proper permissions
- Verify the prefix is correct
- Ensure the bot is online and connected

**Database errors:**
- Check file permissions for the database file
- Ensure SQLite is properly installed
- Verify database schema is up to date

**Permission errors:**
- Ensure bot role is high enough in the hierarchy
- Check that required permissions are granted
- Verify channel-specific permissions

**Giveaway tickets not creating:**
- Check "Manage Channels" permission
- Verify bot can create channels in the server
- Ensure proper role hierarchy for channel creation

### Debug Mode
Set `NODE_ENV=development` in your `.env` file for detailed logging.

## 📝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Code Style
- Use consistent indentation (2 spaces)
- Follow ESLint configuration
- Add comments for complex logic
- Use descriptive variable names

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Join our Discord server: [Support Server](https://discord.gg/example)
- Check the documentation wiki

## 🔄 Updates

### Version 2.0.0 (Node.js Edition)
- Complete rewrite in Node.js
- Enhanced performance and stability
- Advanced giveaway system with tickets
- Improved auto-reaction system
- Better error handling and logging
- Comprehensive documentation

### Planned Features
- Music system integration
- Web dashboard
- Custom command creation
- Advanced analytics
- Multi-language support

---

**Made with ❤️ by Manus AI**

