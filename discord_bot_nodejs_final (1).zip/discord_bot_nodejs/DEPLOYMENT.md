# Deployment Guide - Discord Economy Bot (Node.js)

This guide covers various deployment options for the Discord Economy Bot, from local development to production hosting.

## 🏠 Local Development

### Prerequisites
- Node.js 18.0.0 or higher
- npm or yarn
- Git

### Setup Steps
1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd discord_bot_nodejs
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env with your bot token and settings
   ```

4. **Run the bot**
   ```bash
   npm start
   ```

## ☁️ Cloud Deployment Options

### 1. Heroku Deployment

Heroku is a popular platform for hosting Node.js applications with free and paid tiers.

#### Prerequisites
- Heroku account
- Heroku CLI installed

#### Deployment Steps

1. **Prepare your project**
   ```bash
   # Ensure package.json has start script
   npm init -y
   ```

2. **Create Heroku app**
   ```bash
   heroku create your-bot-name
   ```

3. **Set environment variables**
   ```bash
   heroku config:set DISCORD_TOKEN=your_token_here
   heroku config:set PREFIX=!
   heroku config:set NODE_ENV=production
   ```

4. **Deploy**
   ```bash
   git add .
   git commit -m "Deploy to Heroku"
   git push heroku main
   ```

5. **Scale the worker**
   ```bash
   heroku ps:scale worker=1
   ```

#### Heroku Configuration Files

**Procfile**
```
worker: node index.js
```

**package.json** (ensure these scripts exist)
```json
{
  "scripts": {
    "start": "node index.js",
    "dev": "nodemon index.js"
  },
  "engines": {
    "node": "18.x"
  }
}
```

### 2. Railway Deployment

Railway offers modern hosting with automatic deployments from GitHub.

#### Setup Steps

1. **Connect GitHub repository**
   - Visit [Railway.app](https://railway.app)
   - Connect your GitHub account
   - Import your bot repository

2. **Configure environment variables**
   - Go to your project settings
   - Add environment variables:
     - `DISCORD_TOKEN`
     - `PREFIX`
     - `NODE_ENV=production`

3. **Deploy**
   - Railway automatically deploys on git push
   - Monitor deployment in the Railway dashboard

#### Railway Configuration

**railway.json**
```json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "node index.js",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}
```

### 3. DigitalOcean App Platform

DigitalOcean's App Platform provides a simple deployment solution.

#### Setup Steps

1. **Create new app**
   - Go to DigitalOcean App Platform
   - Connect your GitHub repository

2. **Configure build settings**
   - Build Command: `npm install`
   - Run Command: `node index.js`

3. **Set environment variables**
   - Add all required environment variables
   - Ensure `NODE_ENV=production`

4. **Deploy**
   - Click "Create App"
   - Monitor deployment progress

### 4. Render Deployment

Render offers free hosting for Node.js applications.

#### Setup Steps

1. **Connect repository**
   - Visit [Render.com](https://render.com)
   - Connect your GitHub repository

2. **Configure service**
   - Service Type: Web Service
   - Build Command: `npm install`
   - Start Command: `node index.js`

3. **Environment variables**
   - Add all required variables in Render dashboard

4. **Deploy**
   - Render automatically deploys and provides a URL

## 🖥️ VPS/Dedicated Server Deployment

### Ubuntu/Debian Server Setup

#### 1. Server Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Install Git
sudo apt install git -y
```

#### 2. Deploy the Bot

```bash
# Clone repository
git clone <repository-url>
cd discord_bot_nodejs

# Install dependencies
npm install --production

# Create environment file
cp .env.example .env
nano .env  # Edit with your settings
```

#### 3. PM2 Configuration

**ecosystem.config.js**
```javascript
module.exports = {
  apps: [{
    name: 'discord-bot',
    script: 'index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
```

#### 4. Start with PM2

```bash
# Create logs directory
mkdir logs

# Start the bot
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
```

#### 5. Nginx Reverse Proxy (Optional)

If you plan to add a web dashboard later:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### CentOS/RHEL Server Setup

```bash
# Install Node.js
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Install PM2
sudo npm install -g pm2

# Follow similar steps as Ubuntu deployment
```

## 🐳 Docker Deployment

### Dockerfile

```dockerfile
FROM node:18-alpine

# Create app directory
WORKDIR /usr/src/app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy app source
COPY . .

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001

# Change ownership
RUN chown -R nodejs:nodejs /usr/src/app
USER nodejs

# Expose port (if needed for future web dashboard)
EXPOSE 3000

# Start the bot
CMD ["node", "index.js"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  discord-bot:
    build: .
    restart: unless-stopped
    environment:
      - DISCORD_TOKEN=${DISCORD_TOKEN}
      - PREFIX=${PREFIX}
      - NODE_ENV=production
    volumes:
      - ./data:/usr/src/app/data
    networks:
      - bot-network

networks:
  bot-network:
    driver: bridge
```

### Docker Deployment Commands

```bash
# Build and run
docker-compose up -d

# View logs
docker-compose logs -f

# Update
docker-compose pull
docker-compose up -d
```

## 🔧 Environment Configuration

### Required Environment Variables

```env
# Discord Bot Configuration
DISCORD_TOKEN=your_bot_token_here
PREFIX=!
OWNER_ID=your_discord_user_id

# Database Configuration (optional)
DATABASE_URL=sqlite:./data/bot.db

# Logging Configuration
LOG_LEVEL=info
NODE_ENV=production

# Feature Toggles (optional)
ENABLE_ECONOMY=true
ENABLE_MODERATION=true
ENABLE_GIVEAWAYS=true
```

### Optional Configuration

```env
# API Keys (for future features)
WEATHER_API_KEY=your_weather_api_key
YOUTUBE_API_KEY=your_youtube_api_key

# Webhook URLs
ERROR_WEBHOOK_URL=your_error_webhook_url
LOG_WEBHOOK_URL=your_log_webhook_url

# Performance Settings
MAX_MEMORY=512
COMMAND_COOLDOWN=3
```

## 📊 Monitoring and Maintenance

### Health Checks

Create a health check endpoint:

```javascript
// Add to index.js
const express = require('express');
const app = express();

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    botStatus: client.isReady() ? 'connected' : 'disconnected'
  });
});

app.listen(process.env.PORT || 3000);
```

### Log Management

```bash
# PM2 log management
pm2 logs discord-bot
pm2 flush  # Clear logs

# Log rotation setup
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30
```

### Backup Strategy

```bash
#!/bin/bash
# backup.sh - Database backup script

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
DB_FILE="./data/bot.db"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
cp $DB_FILE "$BACKUP_DIR/bot_backup_$DATE.db"

# Keep only last 30 backups
find $BACKUP_DIR -name "bot_backup_*.db" -mtime +30 -delete

echo "Backup completed: bot_backup_$DATE.db"
```

### Automated Updates

```bash
#!/bin/bash
# update.sh - Automated update script

cd /path/to/discord_bot_nodejs

# Pull latest changes
git pull origin main

# Install dependencies
npm install --production

# Restart bot
pm2 restart discord-bot

echo "Bot updated and restarted"
```

## 🚨 Troubleshooting

### Common Issues

**Bot not starting:**
```bash
# Check PM2 status
pm2 status

# View error logs
pm2 logs discord-bot --err

# Restart bot
pm2 restart discord-bot
```

**Database issues:**
```bash
# Check database file permissions
ls -la data/bot.db

# Fix permissions
chmod 644 data/bot.db
```

**Memory issues:**
```bash
# Monitor memory usage
pm2 monit

# Increase memory limit
pm2 restart discord-bot --max-memory-restart 2G
```

### Performance Optimization

1. **Enable clustering** (for high-traffic bots):
   ```javascript
   // ecosystem.config.js
   instances: 'max',
   exec_mode: 'cluster'
   ```

2. **Database optimization**:
   ```sql
   -- Add indexes for frequently queried columns
   CREATE INDEX idx_users_id ON users(id);
   CREATE INDEX idx_giveaways_guild ON giveaways(guild_id);
   ```

3. **Memory management**:
   ```javascript
   // Add to index.js
   setInterval(() => {
     if (global.gc) {
       global.gc();
     }
   }, 30000);
   ```

## 🔐 Security Best Practices

1. **Environment Variables**: Never commit tokens to version control
2. **Permissions**: Run with minimal required permissions
3. **Updates**: Keep dependencies updated regularly
4. **Monitoring**: Set up error tracking and monitoring
5. **Backups**: Regular database backups
6. **Firewall**: Configure firewall rules appropriately

## 📈 Scaling Considerations

### Horizontal Scaling
- Use Redis for shared state
- Implement database clustering
- Load balance across multiple instances

### Vertical Scaling
- Increase server resources
- Optimize database queries
- Implement caching strategies

---

**Need help?** Join our [Discord Support Server](https://discord.gg/example) or create an issue on GitHub.

