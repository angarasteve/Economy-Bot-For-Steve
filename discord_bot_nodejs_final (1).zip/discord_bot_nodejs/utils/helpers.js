/**
 * Utility Helper Functions for Discord Bot
 */

const { EmbedBuilder } = require('discord.js');
const ms = require('ms');

/**
 * Create a standard embed with consistent styling
 */
function createEmbed(title, description = '', color = 0x0099FF) {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setTimestamp();
}

/**
 * Create a success embed (green)
 */
function createSuccessEmbed(title, description = '') {
    return createEmbed(title, description, 0x00FF00);
}

/**
 * Create an error embed (red)
 */
function createErrorEmbed(title, description = '') {
    return createEmbed(title, description, 0xFF0000);
}

/**
 * Create a warning embed (yellow)
 */
function createWarningEmbed(title, description = '') {
    return createEmbed(title, description, 0xFFFF00);
}

/**
 * Format numbers with commas
 */
function formatNumber(num) {
    return num.toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
}

/**
 * Format currency
 */
function formatCurrency(amount) {
    return `💰 ${formatNumber(amount)} coins`;
}

/**
 * Parse time string to milliseconds
 */
function parseTime(timeString) {
    const time = ms(timeString);
    return time || null;
}

/**
 * Format duration from milliseconds
 */
function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
}

/**
 * Get random element from array
 */
function getRandomElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

/**
 * Get random number between min and max (inclusive)
 */
function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Capitalize first letter of string
 */
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Truncate string to specified length
 */
function truncate(str, length = 100) {
    return str.length > length ? str.substring(0, length) + '...' : str;
}

/**
 * Check if user has permission
 */
function hasPermission(member, permission) {
    return member.permissions.has(permission);
}

/**
 * Check if user is moderator (has kick members permission)
 */
function isModerator(member) {
    return hasPermission(member, 'KickMembers');
}

/**
 * Check if user is admin (has administrator permission)
 */
function isAdmin(member) {
    return hasPermission(member, 'Administrator');
}

/**
 * Get user mention from ID
 */
function getUserMention(userId) {
    return `<@${userId}>`;
}

/**
 * Get channel mention from ID
 */
function getChannelMention(channelId) {
    return `<#${channelId}>`;
}

/**
 * Get role mention from ID
 */
function getRoleMention(roleId) {
    return `<@&${roleId}>`;
}

/**
 * Create progress bar
 */
function createProgressBar(current, max, length = 10) {
    const percentage = Math.min(current / max, 1);
    const filled = Math.round(length * percentage);
    const empty = length - filled;
    
    return '█'.repeat(filled) + '░'.repeat(empty);
}

/**
 * Paginate array into chunks
 */
function paginate(array, pageSize = 10) {
    const pages = [];
    for (let i = 0; i < array.length; i += pageSize) {
        pages.push(array.slice(i, i + pageSize));
    }
    return pages;
}

/**
 * Wait for specified time
 */
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Clean code blocks from string
 */
function cleanCodeBlock(text) {
    if (text.startsWith('```') && text.endsWith('```')) {
        return text.slice(3, -3);
    }
    if (text.startsWith('`') && text.endsWith('`')) {
        return text.slice(1, -1);
    }
    return text;
}

/**
 * Escape markdown characters
 */
function escapeMarkdown(text) {
    return text.replace(/[\\*_`~]/g, '\\\\$&');
}

/**
 * Generate random color
 */
function getRandomColor() {
    return Math.floor(Math.random() * 16777215);
}

/**
 * Check if string is valid URL
 */
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

/**
 * Get time ago string
 */
function getTimeAgo(date) {
    const now = new Date();
    const diffMs = now - new Date(date);
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffMins > 0) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    return `${diffSecs} second${diffSecs > 1 ? 's' : ''} ago`;
}

module.exports = {
    createEmbed,
    createSuccessEmbed,
    createErrorEmbed,
    createWarningEmbed,
    formatNumber,
    formatCurrency,
    parseTime,
    formatDuration,
    getRandomElement,
    getRandomNumber,
    capitalize,
    truncate,
    hasPermission,
    isModerator,
    isAdmin,
    getUserMention,
    getChannelMention,
    getRoleMention,
    createProgressBar,
    paginate,
    wait,
    cleanCodeBlock,
    escapeMarkdown,
    getRandomColor,
    isValidUrl,
    getTimeAgo
};

